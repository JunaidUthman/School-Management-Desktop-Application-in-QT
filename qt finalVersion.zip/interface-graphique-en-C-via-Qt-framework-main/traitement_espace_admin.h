#ifndef TRAITEMENT_ESPACE_ADMIN_H
#define TRAITEMENT_ESPACE_ADMIN_H

#include <QDialog>

namespace Ui {
class traitement_espace_admin;
}

class traitement_espace_admin : public QDialog
{
    Q_OBJECT

public:
    explicit traitement_espace_admin(QWidget *parent = nullptr);
    ~traitement_espace_admin();

private:
    Ui::traitement_espace_admin *ui;
};

#endif // TRAITEMENT_ESPACE_ADMIN_H
