/********************************************************************************
** Form generated from reading UI file 'mainwindow.ui'
**
** Created by: Qt User Interface Compiler version 6.8.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QLabel>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QWidget *centralwidget;
    QPushButton *espace_admin;
    QPushButton *espace_prf;
    QLabel *label_3;
    QLabel *label_4;
    QLabel *label;
    QLabel *label_2;
    QLabel *label_5;
    QLabel *label_6;
    QMenuBar *menubar;
    QStatusBar *statusbar;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName("MainWindow");
        MainWindow->resize(473, 323);
        MainWindow->setStyleSheet(QString::fromUtf8("background-color:white\n"
"\n"
"   \n"
""));
        centralwidget = new QWidget(MainWindow);
        centralwidget->setObjectName("centralwidget");
        espace_admin = new QPushButton(centralwidget);
        espace_admin->setObjectName("espace_admin");
        espace_admin->setGeometry(QRect(30, 220, 171, 41));
        espace_admin->setStyleSheet(QString::fromUtf8("\n"
"\n"
"QPushButton {\n"
"    background-color: #3498db;\n"
"    color: white;\n"
"    border: none;\n"
"    border-radius: 8px;\n"
"   /* padding: 10px 20px;*/\n"
"    font-size: 14px;\n"
"	font: 9pt \"Sylfaen\";\n"
"    font-weight: bold;\n"
"    cursor: pointer;\n"
"}\n"
"QPushButton:hover {\n"
"    background-color: #rgb(165, 219, 255);\n"
"}\n"
"\n"
"QPushButton:pressed {\n"
"    background-color: #1e6f99;\n"
"  /*  padding-left: 12px;\n"
"    padding-top: 12px;*/\n"
"}\n"
""));
        espace_admin->setIconSize(QSize(28, 18));
        espace_prf = new QPushButton(centralwidget);
        espace_prf->setObjectName("espace_prf");
        espace_prf->setGeometry(QRect(280, 220, 161, 41));
        espace_prf->setStyleSheet(QString::fromUtf8("\n"
"\n"
"QPushButton {\n"
"    background-color: #3498db;\n"
"    color: white;\n"
"    border: none;\n"
"    border-radius: 8px;\n"
"   /* padding: 10px 20px;*/\n"
"    font-size: 14px;\n"
"	font: 9pt \"Sylfaen\";\n"
"    font-weight: bold;\n"
"    cursor: pointer;\n"
"}\n"
"QPushButton:hover {\n"
"    background-color: #rgb(165, 219, 255);\n"
"}\n"
"\n"
"QPushButton:pressed {\n"
"    background-color: #1e6f99;\n"
"  /*  padding-left: 12px;\n"
"    padding-top: 12px;*/\n"
"}\n"
""));
        espace_prf->setIconSize(QSize(28, 18));
        label_3 = new QLabel(centralwidget);
        label_3->setObjectName("label_3");
        label_3->setGeometry(QRect(330, 0, 131, 31));
        label_3->setStyleSheet(QString::fromUtf8("image: url(:/images/uae2.jpeg);"));
        label_4 = new QLabel(centralwidget);
        label_4->setObjectName("label_4");
        label_4->setGeometry(QRect(0, 0, 131, 41));
        label_4->setStyleSheet(QString::fromUtf8("\n"
"image: url(:/images/fsttt.jpeg);"));
        label = new QLabel(centralwidget);
        label->setObjectName("label");
        label->setGeometry(QRect(120, 80, 281, 31));
        label->setStyleSheet(QString::fromUtf8("*{\n"
"color:black;\n"
"	font-family: Sylfaen;\n"
"font-size:15px;\n"
"}"));
        label_2 = new QLabel(centralwidget);
        label_2->setObjectName("label_2");
        label_2->setGeometry(QRect(140, 130, 231, 31));
        label_2->setStyleSheet(QString::fromUtf8("color:black;\n"
"	font-family:Sylfaen;\n"
"font-size:12px;"));
        label_5 = new QLabel(centralwidget);
        label_5->setObjectName("label_5");
        label_5->setGeometry(QRect(40, 230, 18, 18));
        label_5->setStyleSheet(QString::fromUtf8("image: url(:/images/admin.jpeg);\n"
"\n"
"                      min-width: 18px;\n"
"                     min-height: 18px;\n"
"                     max-width: 18px;\n"
"                     max-height: 18px;\n"
"                     \n"
"border-raduis:100px;"));
        label_6 = new QLabel(centralwidget);
        label_6->setObjectName("label_6");
        label_6->setGeometry(QRect(300, 230, 18, 18));
        label_6->setStyleSheet(QString::fromUtf8("image: url(:/images/prof.jpeg);\n"
"\n"
"                      min-width: 18px;\n"
"                     min-height: 18px;\n"
"                     max-width: 18px;\n"
"                     max-height: 18px;\n"
"                     \n"
"border-raduis:100px;"));
        MainWindow->setCentralWidget(centralwidget);
        menubar = new QMenuBar(MainWindow);
        menubar->setObjectName("menubar");
        menubar->setGeometry(QRect(0, 0, 473, 17));
        MainWindow->setMenuBar(menubar);
        statusbar = new QStatusBar(MainWindow);
        statusbar->setObjectName("statusbar");
        MainWindow->setStatusBar(statusbar);

        retranslateUi(MainWindow);

        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QCoreApplication::translate("MainWindow", "MainWindow", nullptr));
        espace_admin->setText(QCoreApplication::translate("MainWindow", "     Espace Administrateur ", nullptr));
        espace_prf->setText(QCoreApplication::translate("MainWindow", "    Espace Professeur", nullptr));
        label_3->setText(QString());
        label_4->setText(QString());
        label->setText(QCoreApplication::translate("MainWindow", "Bienvenue dans le Portail de Gestion LSI", nullptr));
        label_2->setText(QCoreApplication::translate("MainWindow", "Connectez-vous pour acc\303\251der \303\240 votre espace", nullptr));
        label_5->setText(QString());
        label_6->setText(QString());
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H
