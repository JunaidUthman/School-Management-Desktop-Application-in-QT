#include "traitement_admin.h"
#include "ui_traitement_admin.h"
#include "affichage_etudiant_module.h"
#include"MainWindow.h"
#include"affichage_etudiants.h"
#include<QMessageBox>
#include<QPixmap>
#include<QLayoutItem>
#include<QGridLayout>
#include<QGraphicsBlurEffect>

traitement_admin::traitement_admin(QWidget *parent)
    : QDialog(parent)
    , ui(new Ui::traitement_admin)
{
    ui->setupUi(this);
    ui->mainpage->setCurrentIndex(0);
    QPixmap pix("C:/Users/DELL/Desktop/projet QT complet/Nouveau dossier/FST-Tanger-modified.png");
     ui->label_22->setPixmap(pix.scaled(100,100,Qt::KeepAspectRatio));

    QPixmap pix2("C:/Users/DELL/Desktop/projet QT complet/Nouveau dossier/pexels-serpstat-177219-572056.jpg");

    // Ajuster la taille de l'image selon vos besoins
    QPixmap scaledPix = pix2.scaled(800, 800, Qt::KeepAspectRatio);

    // Appliquer un effet de flou
    QGraphicsBlurEffect *blurEffect = new QGraphicsBlurEffect();
    blurEffect->setBlurRadius(15); // Ajuster le rayon pour augmenter/diminuer le flou

    // Créer un QLabel pour afficher l'image
    QLabel *label = ui->label_2;
    label->setPixmap(scaledPix);

    // Appliquer l'effet au QLabel
    label->setGraphicsEffect(blurEffect);



    QString file = "C:/Users/pc/Downloads/Desktop/Documents/login_espace_admin_prf/database_login/database_login/new_db/lsidb.db";


    // Configuration de la connexion à la base SQLite
    db_connection = QSqlDatabase::addDatabase("QSQLITE");
    db_connection.setDatabaseName(file);

    // Vérification de la connexion
    if (db_connection.open()) {
        qDebug() << "db is connected";
    } else {
        qDebug() << "db is not connected: " << db_connection.lastError().text();
    }

    if(db_connection.isOpen()){
        qDebug() << "db is opened";
    }
    else{
        qDebug()<< "db is not opened";
    }

}

traitement_admin::~traitement_admin()
{
    delete ui;
}

void traitement_admin::on_menue_clicked()
{
    ui->mainpage->setCurrentIndex(0);
}


void traitement_admin::on_etudiant_clicked()
{
    ui->mainpage->setCurrentIndex(3);

}
void traitement_admin::on_modules_clicked()
{
    ui->mainpage->setCurrentIndex(5);

    // Récupération des données depuis la base de données
    QSqlQuery query("SELECT * FROM modules", db_connection);

    if (query.exec()) {
        // Effacer le contenu précédent dans le layout (si nécessaire)
        QLayout *oldLayout = ui->gridWidget->layout(); // gridWidget est un QScrollArea ou QWidget
        if (oldLayout) {
            QLayoutItem *item;
            while ((item = oldLayout->takeAt(0)) != nullptr) {
                delete item->widget(); // Supprimer les widgets
                delete item;           // Supprimer les items
            }
            delete oldLayout;
        }

        // Créer un nouveau QGridLayout
        QGridLayout *gridLayout = new QGridLayout(ui->gridWidget);
        ui->gridWidget->setLayout(gridLayout);

        gridLayout->setSpacing(10); // Espacement entre les éléments
        gridLayout->setContentsMargins(10, 10, 10, 10); // Marges autour de la grille

        int row = 0, column = 0;
        const int maxColumns = 3; // Nombre maximum de colonnes dans la grille

        int buttonCount = 0; // Compteur de boutons pour ajuster la taille du contenu

        while (query.next()) {
            QString moduleName = query.value("nom").toString();
            int id_module = query.value("cid").toInt();
            qDebug() << "Le id du module est :" << id_module;

            // Créer un bouton pour chaque module
            QPushButton *moduleButton = new QPushButton(moduleName);
            moduleButton->setSizePolicy(QSizePolicy::Expanding, QSizePolicy::Preferred);
            moduleButton->setMinimumWidth(100);
            moduleButton->setMaximumWidth(150);
            moduleButton->setMinimumHeight(50);  // Définir une hauteur minimale pour les boutons
            moduleButton->setToolTip(moduleName);
            moduleButton->setStyleSheet(
                "QPushButton {"
                "    background-color: #3498DB;"   // Couleur de fond
                "    color: white;"                // Couleur du texte
                "    border: 1px solid #34495E;"  // Bordure
                "    border-radius: 5px;"         // Coins arrondis
                "    padding: 5px;"               // Espacement interne
                "    text-align: left;"           // Aligne le texte à gauche
                "    overflow: hidden;"           // Cache les débordements
                "    text-overflow: ellipsis;"    // Affiche "..." si le texte est trop long
                "    white-space: nowrap;"        // Empêche les retours à la ligne
                "} "
                "QPushButton:hover {"
                "    background-color: #34495E;"  // Couleur de fond au survol
                "} "
                "QPushButton:pressed {"
                "    background-color: #1B2838;"  // Couleur de fond quand le bouton est cliqué
                "}"
                );

            // Connecter le bouton à une action
            connect(moduleButton, &QPushButton::clicked, this, [=]() {
                qDebug() << "Bouton cliqué : " << moduleName;
                affichage_etudiant_module affiche(id_module);
                affiche.exec();
            });

            // Ajouter le bouton au layout
            gridLayout->addWidget(moduleButton, row, column);

            // Gestion des colonnes et des lignes
            column++;
            if (column >= maxColumns) {
                column = 0;
                row++;
            }

            buttonCount++;
        }

        // Ajuster la taille de la zone défilante
        ui->gridWidget->setMinimumHeight(buttonCount / maxColumns * 60); // Calculer la hauteur minimale selon le nombre de boutons

        // Réajuster les colonnes pour qu'elles aient la même largeur
        for (int i = 0; i < maxColumns; ++i) {
            gridLayout->setColumnStretch(i, 1);
        }

        // Actualiser le widget contenu dans le QScrollArea pour déclencher le défilement
        ui->scrollAreaWidgetContents->setMinimumHeight(50 + buttonCount / maxColumns * 60); // Ajuster la hauteur du contenu
    } else {
        qDebug() << "Erreur lors de la récupération des modules : " << query.lastError().text();
    }
}


void traitement_admin::on_professeurs_clicked()
{
    ui->mainpage->setCurrentIndex(1);


}





void traitement_admin::on_pushButton_4_clicked()
{
    close();
}


void traitement_admin::on_page_initiale_clicked()
{
    MainWindow *newMainWindow = new MainWindow();
    newMainWindow->show(); // Show the new main window

    close(); // Close the dialog
}


void traitement_admin::on_lsi1_clicked()
{
    affichage_etudiants e("LSI1",this);
    e.exec();
}


void traitement_admin::on_lsi2_clicked()
{
    affichage_etudiants e("LSI2",this);
    e.exec();
}


void traitement_admin::on_lsi3_clicked()
{
    affichage_etudiants e("LSI3",this);
    e.exec();
}

void traitement_admin::on_pushButton_clicked()
{
    ui->mainpage->setCurrentIndex(2);
    QSqlQuery query("SELECT * FROM profs", db_connection);

    if (query.exec()) {
        ui->prf_table->clear();

        // Définir les en-têtes
        QStringList headers = {"ID", "Nom","Prenom", "Email","Module","Password","Modifier","Supprimer"};
        ui->prf_table->setColumnCount(headers.size());
        ui->prf_table->setHorizontalHeaderLabels(headers);
        ui->prf_table->setRowCount(0);

        // Charger les données ligne par ligne
        int row = 0;
        while (query.next()) {
            ui->prf_table->insertRow(row); // Ajouter une nouvelle ligne
            int id = query.value("id").toInt();

            // Remplir chaque colonne
            ui->prf_table->setItem(row, 0, new QTableWidgetItem(query.value("id").toString()));
            ui->prf_table->setItem(row, 1, new QTableWidgetItem(query.value("nom").toString()));
            ui->prf_table->setItem(row, 2, new QTableWidgetItem(query.value("prenom").toString()));
            ui->prf_table->setItem(row, 3, new QTableWidgetItem(query.value("email").toString()));
            ui->prf_table->setItem(row, 4, new QTableWidgetItem(query.value("module").toString()));
            ui->prf_table->setItem(row, 5, new QTableWidgetItem(query.value("password").toString()));

            QPushButton *editButton = new QPushButton("Modifier");
            connect(editButton, &QPushButton::clicked, this, [=]() {
                // Récupérer les nouvelles valeurs de la ligne
                QString id = ui->prf_table->item(row, 0)->text();
                QString nom = ui->prf_table->item(row, 1)->text();
                QString prenom = ui->prf_table->item(row, 2)->text();
                QString email = ui->prf_table->item(row, 3)->text();
                QString module = ui->prf_table->item(row, 4)->text();
                QString password = ui->prf_table->item(row, 5)->text();

                // Préparer la requête de mise à jour
                QSqlQuery updateQuery(db_connection);
                updateQuery.prepare("UPDATE profs SET nom=:nom,prenom=:prenom ,email=:email,module=:module,password=:password WHERE id=:id");
                updateQuery.bindValue(":nom", nom);
                updateQuery.bindValue(":prenom", prenom);
                updateQuery.bindValue(":email", email);
                updateQuery.bindValue(":module", module);
                updateQuery.bindValue(":password", password);
                updateQuery.bindValue(":id", id);

                if (updateQuery.exec()) {
                    qDebug() << "le prof est modifié";
                }
                else {
                    qDebug() << "le prof n'est pas modifié";
                }
            });
            ui->prf_table->setCellWidget(row, 6, editButton);

            QPushButton *deleteButton = new QPushButton("Supprimer");
            connect(deleteButton, &QPushButton::clicked, this, [=]() {
                QSqlQuery delete_query(db_connection);
                delete_query.prepare("DELETE FROM profs WHERE id=:id");
                delete_query.bindValue(":id", id);
                if(delete_query.exec()){
                    qDebug() << "le prof est supprimé";
                }
                else{
                    qDebug() << "il ya un probleme lors de la suppression du prof";
                }
            });

            // Ajouter le bouton à la dernière colonne
            ui->prf_table->setCellWidget(row, 7, deleteButton);

            row++;
        }
    } else {
        // Gérer les erreurs de requête
        qDebug() << "Failed to execute query:" << query.lastError().text();
    }
}


void traitement_admin::on_butnenr_clicked()
{
    QString nom = ui->lineEdit_11->text();
    QString prenom = ui->lineEdit_12->text();
    QString cne = ui->lineEdit_13->text();
    QString adresse = ui->lineEdit_14->text();
    QString date_naissance = ui->lineEdit_15->text();  // Format attendu : yyyy-MM-dd
    QString annee_bac = ui->lineEdit_16->text();
    QString diplome_obtenu = ui->lineEdit_17->text();
    QString niveau_etudes = ui->lineEdit_18->text();  // Récupérer la valeur de niveau_etudes

    // Vérification des champs vides
    if (nom.isEmpty() || prenom.isEmpty() || cne.isEmpty() || adresse.isEmpty() ||
        date_naissance.isEmpty() || annee_bac.isEmpty() || diplome_obtenu.isEmpty() || niveau_etudes.isEmpty()) {
        QMessageBox::warning(this, "Erreur", "Veuillez remplir tous les champs !");
        return;
    }

    // Vérifier si la base de données est ouverte
    if (!db_connection.isOpen()) {
        QMessageBox::critical(this, "Erreur", "La base de données n'est pas accessible.");
        return;
    }

    // Démarrer une transaction
    if (!db_connection.transaction()) {
        qDebug() << "Erreur lors du démarrage de la transaction: " << db_connection.lastError().text();
        QMessageBox::critical(this, "Erreur", "Impossible de démarrer une transaction avec la base de données.");
        return;
    }

    try {
        // Insérer l'étudiant dans la table students
        QSqlQuery query;
        query.prepare("INSERT INTO students (nom, prenom, cne, adresse, date_naissance, annee_bac, diplome_obtenu, niveau_etudes) "
                      "VALUES (:nom, :prenom, :cne, :adresse, :date_naissance, :annee_bac, :diplome_obtenu, :niveau_etudes)");
        query.bindValue(":nom", nom);
        query.bindValue(":prenom", prenom);
        query.bindValue(":cne", cne);
        query.bindValue(":adresse", adresse);
        query.bindValue(":date_naissance", date_naissance);
        query.bindValue(":annee_bac", annee_bac);
        query.bindValue(":diplome_obtenu", diplome_obtenu);
        query.bindValue(":niveau_etudes", niveau_etudes);

        if (!query.exec()) {
            throw std::runtime_error("Erreur lors de l'insertion dans la table students: " +
                                     query.lastError().text().toStdString());
        }
        else{

        }

        // Récupérer l'id de l'étudiant inséré
        int id_etudiant = query.lastInsertId().toInt();

        // Récupérer tous les modules correspondant au niveau d'études
        QSqlQuery queryModules;
        queryModules.prepare("SELECT cid FROM modules WHERE niveau = :niveau_et");
        queryModules.bindValue(":niveau_et", niveau_etudes);

        if (!queryModules.exec()) {
            throw std::runtime_error("Erreur lors de la récupération des modules: " +
                                     queryModules.lastError().text().toStdString());
        }

        // Insérer chaque module dans la table inscription
        bool hasModules = false;
        while (queryModules.next()) {
            hasModules = true;
            int id_module = queryModules.value(0).toInt();

            QSqlQuery queryInscription;
            queryInscription.prepare("INSERT INTO inscription (id_etudiant, id_module) VALUES (:id_etudiant, :id_module)");
            queryInscription.bindValue(":id_etudiant", id_etudiant);
            queryInscription.bindValue(":id_module", id_module);

            if (!queryInscription.exec()) {
                throw std::runtime_error("Erreur lors de l'insertion dans la table inscription: " +
                                         queryInscription.lastError().text().toStdString());
            }
        }

        if (!hasModules) {
            throw std::runtime_error("Aucun module trouvé pour le niveau d'études: " + niveau_etudes.toStdString());
        }

        // Valider la transaction
        if (!db_connection.commit()) {
            throw std::runtime_error("Erreur lors de la validation de la transaction: " +
                                     db_connection.lastError().text().toStdString());
        }

        QMessageBox::information(this, "Succès", "Étudiant et modules enregistrés avec succès !");
        qDebug() << "Transaction validée : Étudiant et modules insérés.";

        // Réinitialiser les champs
        ui->lineEdit_11->clear();
        ui->lineEdit_12->clear();
        ui->lineEdit_13->clear();
        ui->lineEdit_14->clear();
        ui->lineEdit_15->clear();
        ui->lineEdit_16->clear();
        ui->lineEdit_17->clear();
        ui->lineEdit_18->clear();

    } catch (const std::runtime_error &e) {
        qDebug() << "Erreur: " << e.what();

        // Annuler la transaction en cas d'erreur
        db_connection.rollback();
        QMessageBox::critical(this, "Erreur", QString("Une erreur s'est produite : %1").arg(e.what()));
    }
}



void traitement_admin::on_ajouter_prof_clicked()
{
    ui->mainpage->setCurrentIndex(6);
}



void traitement_admin::on_btnenregistrer_clicked()
{
    // Récupérer les informations saisies par l'admin
    QString nom = ui->lineEdit->text();
    QString prenom = ui->lineEdit_2->text();
    QString email = ui->lineEdit_3->text();
    QString password = ui->lineEdit_4->text();
    QString module = ui->lineEdit_5->text();

    // Vérification des champs vides
    if (nom.isEmpty() || prenom.isEmpty() || email.isEmpty() || password.isEmpty() || module.isEmpty()) {
        QMessageBox::warning(this, "Erreur", "Veuillez remplir tous les champs !");
        return;
    }

    // Vérifier si la base de données est ouverte
    if (!db_connection.isOpen()) {
        qDebug() << "Database is not open!";
        QMessageBox::critical(this, "Erreur", "La base de données n'est pas accessible.");
        return;
    }

    // Construire la requête SQL pour insérer un professeur
    QSqlQuery query;
    query.prepare("INSERT INTO profs (nom, prenom, email, password, module) "
                  "VALUES (:nom, :prenom, :email, :password, :module)");

    // Lier les valeurs aux paramètres
    query.bindValue(":nom", nom);
    query.bindValue(":prenom", prenom);
    query.bindValue(":email", email);  // Correction: Utiliser "email"
    query.bindValue(":password", password);  // Correction: Utiliser "password"
    query.bindValue(":module", module);  // Correction: Utiliser "module"

    // Exécuter la requête SQL
    if (query.exec()) {
        QMessageBox::information(this, "Succès", "Le professeur a été ajouté avec succès !");
        qDebug() << "Insertion réussie dans la table profs !";

        // Réinitialiser les champs du formulaire
        ui->lineEdit->clear();
        ui->lineEdit_2->clear();
        ui->lineEdit_3->clear();
        ui->lineEdit_4->clear();
        ui->lineEdit_5->clear();
    } else {
        QMessageBox::critical(this, "Erreur", "Erreur lors de l'insertion du professeur : " + query.lastError().text());
        qDebug() << "Erreur lors de l'insertion dans la table profs : " << query.lastError().text();
    }
}


void traitement_admin::on_btn5_clicked()
{
    ui->mainpage->setCurrentIndex(4); // Remplacez 1 par l'index de la page que vous souhaitez afficher
}


void traitement_admin::on_lsi1_2_clicked()
{
    // Chemin de l'image à afficher
    QString imagePath = "C:/Users/pc/Downloads/Desktop/Documents/login_espace_admin_prf/lsi1.png"; // Remplacez par le chemin réel de l'image

    // Récupérer le QStackedWidget
    QStackedWidget* stackedWidget = ui->mainpage;

    // Accéder à la page spécifique (page 4 dans ce cas, index 3 car l'index commence à 0)
    QWidget* page4 = stackedWidget->widget(4);  // index 3 correspond à la 4ème page

    // Rechercher le QLabel dans cette page (assurez-vous que l'objet QLabel dans cette page s'appelle label_image)
    QLabel* labelImage = page4->findChild<QLabel*>("label_image");

    // Vérifier si le QLabel a été trouvé
    if (labelImage) {
        // Charger l'image dans le QPixmap
        QPixmap pixmap(imagePath);

        // Vérifier si l'image a bien été chargée
        if (!pixmap.isNull()) {
            // Afficher l'image dans le QLabel
            labelImage->setPixmap(pixmap);
            labelImage->setScaledContents(true);  // Adapter l'image à la taille du QLabel
        } else {
            // Afficher un message d'erreur si l'image n'a pas pu être chargée
            QMessageBox::warning(this, "Erreur", "Image non trouvée !");
        }
    } else {
        // Afficher un message d'erreur si le QLabel n'a pas été trouvé
        QMessageBox::warning(this, "Erreur", "Le QLabel pour afficher l'image n'a pas été trouvé !");
    }
}


void traitement_admin::on_lsi2_2_clicked()
{
    // Chemin de l'image à afficher
    QString imagePath = "C:/Users/pc/Downloads/Desktop/Documents/login_espace_admin_prf/lsi2.png"; // Remplacez par le chemin réel de l'image

    // Récupérer le QStackedWidget
    QStackedWidget* stackedWidget = ui->mainpage;

    // Accéder à la page spécifique (page 4 dans ce cas, index 3 car l'index commence à 0)
    QWidget* page4 = stackedWidget->widget(4);  // index 3 correspond à la 4ème page

    // Rechercher le QLabel dans cette page (assurez-vous que l'objet QLabel dans cette page s'appelle label_image)
    QLabel* labelImage = page4->findChild<QLabel*>("label_image");

    // Vérifier si le QLabel a été trouvé
    if (labelImage) {
        // Charger l'image dans le QPixmap
        QPixmap pixmap(imagePath);

        // Vérifier si l'image a bien été chargée
        if (!pixmap.isNull()) {
            // Afficher l'image dans le QLabel
            labelImage->setPixmap(pixmap);
            labelImage->setScaledContents(true);  // Adapter l'image à la taille du QLabel
        } else {
            // Afficher un message d'erreur si l'image n'a pas pu être chargée
            QMessageBox::warning(this, "Erreur", "Image non trouvée !");
        }
    } else {
        // Afficher un message d'erreur si le QLabel n'a pas été trouvé
        QMessageBox::warning(this, "Erreur", "Le QLabel pour afficher l'image n'a pas été trouvé !");
    }
}


void traitement_admin::on_lsi3_2_clicked()
{
    // Chemin de l'image à afficher
    QString imagePath = "C:/Users/pc/Downloads/Desktop/Documents/login_espace_admin_prf/lsi3.png"; // Remplacez par le chemin réel de l'image

    // Récupérer le QStackedWidget
    QStackedWidget* stackedWidget = ui->mainpage;

    // Accéder à la page spécifique (page 4 dans ce cas, index 3 car l'index commence à 0)
    QWidget* page4 = stackedWidget->widget(4);  // index 3 correspond à la 4ème page

    // Rechercher le QLabel dans cette page (assurez-vous que l'objet QLabel dans cette page s'appelle label_image)
    QLabel* labelImage = page4->findChild<QLabel*>("label_image");

    // Vérifier si le QLabel a été trouvé
    if (labelImage) {
        // Charger l'image dans le QPixmap
        QPixmap pixmap(imagePath);

        // Vérifier si l'image a bien été chargée
        if (!pixmap.isNull()) {
            // Afficher l'image dans le QLabel
            labelImage->setPixmap(pixmap);
            labelImage->setScaledContents(true);  // Adapter l'image à la taille du QLabel
        } else {
            // Afficher un message d'erreur si l'image n'a pas pu être chargée
            QMessageBox::warning(this, "Erreur", "Image non trouvée !");
        }
    } else {
        // Afficher un message d'erreur si le QLabel n'a pas été trouvé
        QMessageBox::warning(this, "Erreur", "Le QLabel pour afficher l'image n'a pas été trouvé !");
    }
}


void traitement_admin::on_label_2_linkActivated(const QString &link)
{

}


void traitement_admin::on_label_22_linkActivated(const QString &link)
{

}

