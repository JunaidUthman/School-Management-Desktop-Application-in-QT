select * from admin;
select * from profs;
select * from modules;
update profs set module='Théorie des graphes & Applications' where id=1;