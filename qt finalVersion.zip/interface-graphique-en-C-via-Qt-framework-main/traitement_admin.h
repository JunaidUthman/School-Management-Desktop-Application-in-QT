#ifndef TRAITEMENT_ADMIN_H
#define TRAITEMENT_ADMIN_H

#include <QDialog>
#include<QtSql>

namespace Ui {
class traitement_admin;
}

class traitement_admin : public QDialog
{
    Q_OBJECT

public:
    explicit traitement_admin(QWidget *parent = nullptr);
    ~traitement_admin();

private slots:
    void on_menue_clicked();

    void on_etudiant_clicked();

    void on_pushButton_4_clicked();

    void on_page_initiale_clicked();


    void on_lsi1_clicked();

    void on_lsi2_clicked();

    void on_lsi3_clicked();

    void on_professeurs_clicked();

    void on_modules_clicked();


    void on_pushButton_clicked();

    void on_butnenr_clicked();

    void on_ajouter_prof_clicked();


    void on_btnenregistrer_clicked();

    void on_btn5_clicked();

    void on_lsi1_2_clicked();

    void on_lsi2_2_clicked();

    void on_lsi3_2_clicked();

    void on_label_2_linkActivated(const QString &link);

    void on_label_22_linkActivated(const QString &link);

private:
    Ui::traitement_admin *ui;
    QSqlDatabase db_connection;
};

#endif // TRAITEMENT_ADMIN_H
