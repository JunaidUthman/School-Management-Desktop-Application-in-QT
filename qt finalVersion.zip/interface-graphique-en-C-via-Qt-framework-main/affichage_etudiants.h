#ifndef AFFICHAGE_ETUDIANTS_H
#define AFFICHAGE_ETUDIANTS_H

#include <QDialog>
#include <QString>
#include<QtSql>

namespace Ui {
class affichage_etudiants;
}

class affichage_etudiants : public QDialog
{
    Q_OBJECT

public:
    explicit affichage_etudiants(const QString &groupe, QWidget *parent = nullptr);
    ~affichage_etudiants();

private:
    Ui::affichage_etudiants *ui;
    QString groupe;
    QSqlDatabase db_connection;
};

#endif // AFFICHAGE_ETUDIANTS_H
