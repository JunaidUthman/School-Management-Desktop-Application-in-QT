#include "espace_admin.h"
#include "ui_espace_admin.h"
#include "mainwindow.h"
#include"traitement_admin.h"
#include<QMessageBox>

espace_admin::espace_admin(QWidget *parent )
    : QDialog(parent)
    , ui(new Ui::espace_admin)
{
    ui->setupUi(this);
    QString file = "C:/Users/pc/Downloads/Desktop/Documents/login_espace_admin_prf/database_login/database_login/new_db/lsidb.db";

    // Configuration de la connexion à la base SQLite
    db_connection = QSqlDatabase::addDatabase("QSQLITE");
    db_connection.setDatabaseName(file);

    // Vérification de la connexion
    if (db_connection.open()) {
        qDebug() << "db is connected";
    } else {
        qDebug() << "db is not connected: " << db_connection.lastError().text();
    }
}

espace_admin::~espace_admin()
{
    delete ui;
}

void espace_admin::on_submit_clicked()
{
    // Récupérer les informations saisies par l'utilisateur
    QString email = ui->email_input->text(); // Assurez-vous que 'email_input' est le nom correct du champ email
    QString password = ui->password_input->text(); // Assurez-vous que 'password_input' est le nom correct du champ password

    // Vérifier si la base de données est ouverte
    if (!db_connection.isOpen()) {
        qDebug() << "Database is not open!";
        return;
    }

    // Préparer la requête SQL
    QSqlQuery query(db_connection);
    query.prepare("SELECT * FROM admin WHERE email = :email AND password = :password");
    query.bindValue(":email", email);
    query.bindValue(":password", password);

    // Exécuter la requête
    if (query.exec()) {
        if (query.next()) {
            // Succès : L'utilisateur existe
            qDebug() << "Login successful!";
            QMessageBox::information(this, "Login", "Login successful!");
            this->hide();
            traitement_admin t;
            t.setModal(true);
            t.exec();

        } else {
            // Erreur : Informations incorrectes
            qDebug() << "Invalid email or password!";
            QMessageBox::warning(this, "Login", "Invalid email or password!");
        }
    } else {
        // Erreur d'exécution de la requête
        qDebug() << "Query failed: " << query.lastError().text();
        QMessageBox::critical(this, "Error", "Failed to execute query!");
    }

}


void espace_admin::on_menue_clicked()
{
    // Create a new instance of the main window
    MainWindow *newMainWindow = new MainWindow();
    newMainWindow->show(); // Show the new main window

    close(); // Close the dialog
}


void espace_admin::on_exit_clicked()
{
    close();
}

