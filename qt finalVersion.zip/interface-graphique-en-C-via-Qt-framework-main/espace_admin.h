#ifndef ESPACE_ADMIN_H
#define ESPACE_ADMIN_H

#include <QDialog>
#include<QtSql>

namespace Ui {
class espace_admin;
}

class espace_admin : public QDialog
{
    Q_OBJECT

public:
    explicit espace_admin(QWidget *parent = nullptr);
    ~espace_admin();



private slots:

    void on_submit_clicked();

    void on_menue_clicked();

    void on_exit_clicked();

private:
    Ui::espace_admin *ui;
    QSqlDatabase db_connection;
};

#endif // ESPACE_ADMIN_H
