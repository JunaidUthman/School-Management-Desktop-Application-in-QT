#include "affichage_etudiants.h"
#include "ui_affichage_etudiants.h"
#include<QPushButton>
affichage_etudiants::affichage_etudiants(const QString &groupe, QWidget *parent)
    : QDialog(parent), ui(new Ui::affichage_etudiants), groupe(groupe)
{
    ui->setupUi(this);
    QString file = "C:/Users/pc/Downloads/Desktop/Documents/login_espace_admin_prf/database_login/database_login/new_db/lsidb.db";
    db_connection = QSqlDatabase::addDatabase("QSQLITE");
    db_connection.setDatabaseName(file);

    // Vérification de la connexion
    if (db_connection.open()) {
        qDebug() << "db is connected";
    } else {
        qDebug() << "db is not connected: " << db_connection.lastError().text();
    }
    QSqlQuery query(db_connection);
    query.prepare("SELECT * FROM students WHERE niveau_etudes =:niveau_etudes");

    // Lier la valeur de groupe passée au constructeur
    query.bindValue(":niveau_etudes", groupe);

    if (query.exec()) {
        // Configurer le tableau pour afficher les étudiants
        ui->etudiantTable->clear(); // Effacer les données précédentes

        // Définir les en-têtes (inclure la colonne "Supprimer")
        QStringList headers = {"ID", "Nom","Prenom", "CNE", "Adresse","Date-naissance","anner_bac", "diplome_obtenu","niveau_etudes", "Modifier", "Supprimer"};
        ui->etudiantTable->setColumnCount(headers.size());
        ui->etudiantTable->setHorizontalHeaderLabels(headers);

        ui->etudiantTable->setEditTriggers(QAbstractItemView::DoubleClicked | QAbstractItemView::SelectedClicked);


        // Charger les données ligne par ligne
        int row = 0;
        while (query.next()) {
            qDebug() << "parcoure";
            // Récupérer l'ID avant toute autre opération
            int id = query.value("id").toInt();

            ui->etudiantTable->insertRow(row); // Ajouter une nouvelle ligne

            // Remplir chaque colonne
            ui->etudiantTable->setItem(row, 0, new QTableWidgetItem(QString::number(id)));
            ui->etudiantTable->setItem(row, 1, new QTableWidgetItem(query.value("nom").toString()));
            ui->etudiantTable->setItem(row, 2, new QTableWidgetItem(query.value("prenom").toString()));
            ui->etudiantTable->setItem(row, 3, new QTableWidgetItem(query.value("cne").toString()));
            ui->etudiantTable->setItem(row, 4, new QTableWidgetItem(query.value("adresse").toString()));
            ui->etudiantTable->setItem(row, 5, new QTableWidgetItem(query.value("date_naissance").toString()));
            ui->etudiantTable->setItem(row, 6, new QTableWidgetItem(query.value("annee_bac").toString()));
            ui->etudiantTable->setItem(row, 7, new QTableWidgetItem(query.value("diplome_obtenu").toString()));
            ui->etudiantTable->setItem(row, 8, new QTableWidgetItem(query.value("niveau_etudes").toString()));

            QPushButton *editButton = new QPushButton("Modifier");
            connect(editButton, &QPushButton::clicked, this, [=]() {
                // Récupérer les nouvelles valeurs de la ligne
                QString id = ui->etudiantTable->item(row, 0)->text();
                QString nom = ui->etudiantTable->item(row, 1)->text();
                QString prenom = ui->etudiantTable->item(row, 2)->text();
                QString cne = ui->etudiantTable->item(row, 3)->text();
                QString adresse = ui->etudiantTable->item(row, 4)->text();
                QString date = ui->etudiantTable->item(row, 5)->text();
                QString annee = ui->etudiantTable->item(row, 6)->text();
                QString diplome = ui->etudiantTable->item(row, 7)->text();
                QString niveau = ui->etudiantTable->item(row, 8)->text();

                // Préparer la requête de mise à jour
                QSqlQuery updateQuery(db_connection);
                updateQuery.prepare("UPDATE students SET nom=:nom,prenom=:prenom ,cne=:cne,adresse=:adresse,date_naissance=:date, annee_bac=:annee, diplome_obtenu=:diplome,niveau_etudes=:niveau WHERE id=:id");
                updateQuery.bindValue(":nom", nom);
                updateQuery.bindValue(":prenom", prenom);
                updateQuery.bindValue(":cne", cne);
                updateQuery.bindValue(":adresse", adresse);
                updateQuery.bindValue(":date", date);
                updateQuery.bindValue(":annee", annee);
                updateQuery.bindValue(":diplome", diplome);
                updateQuery.bindValue(":niveau", niveau);
                updateQuery.bindValue(":id", id);

                if (updateQuery.exec()) {
                    qDebug() << "letudiant modifié";
                }
                else {
                    qDebug() << "letudian n'est pas modifié";
                }
            });
            ui->etudiantTable->setCellWidget(row, 9, editButton);

            QPushButton *deleteButton = new QPushButton("Supprimer");
            connect(deleteButton, &QPushButton::clicked, this, [=]() {
                QSqlQuery delete_query(db_connection);
                delete_query.prepare("DELETE FROM students WHERE id=:id");
                delete_query.bindValue(":id", id);
                if(delete_query.exec()){
                    qDebug() << "letudiant selectionné est supprimé";
                }
                else{
                     qDebug() << "il ya un probleme lors de la suppression de l'etudiant";
                }
            });

            // Ajouter le bouton à la dernière colonne
            ui->etudiantTable->setCellWidget(row, 10, deleteButton);

            row++;
        }
    } else {
        // Gérer les erreurs de requête
        qDebug() << "Failed to execute query:" << query.lastError().text();
    }


}

affichage_etudiants::~affichage_etudiants()
{
    delete ui;
}
