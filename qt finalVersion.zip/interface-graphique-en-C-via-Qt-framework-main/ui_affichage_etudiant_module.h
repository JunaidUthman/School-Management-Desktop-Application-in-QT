/********************************************************************************
** Form generated from reading UI file 'affichage_etudiant_module.ui'
**
** Created by: Qt User Interface Compiler version 6.8.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_AFFICHAGE_ETUDIANT_MODULE_H
#define UI_AFFICHAGE_ETUDIANT_MODULE_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QTableWidget>

QT_BEGIN_NAMESPACE

class Ui_affichage_etudiant_module
{
public:
    QLabel *label;
    QTableWidget *etudiantTable;
    QLineEdit *module;

    void setupUi(QDialog *affichage_etudiant_module)
    {
        if (affichage_etudiant_module->objectName().isEmpty())
            affichage_etudiant_module->setObjectName("affichage_etudiant_module");
        affichage_etudiant_module->resize(400, 300);
        label = new QLabel(affichage_etudiant_module);
        label->setObjectName("label");
        label->setGeometry(QRect(10, 0, 41, 41));
        etudiantTable = new QTableWidget(affichage_etudiant_module);
        etudiantTable->setObjectName("etudiantTable");
        etudiantTable->setGeometry(QRect(5, 71, 391, 221));
        module = new QLineEdit(affichage_etudiant_module);
        module->setObjectName("module");
        module->setGeometry(QRect(110, 10, 271, 20));

        retranslateUi(affichage_etudiant_module);

        QMetaObject::connectSlotsByName(affichage_etudiant_module);
    } // setupUi

    void retranslateUi(QDialog *affichage_etudiant_module)
    {
        affichage_etudiant_module->setWindowTitle(QCoreApplication::translate("affichage_etudiant_module", "Dialog", nullptr));
        label->setText(QCoreApplication::translate("affichage_etudiant_module", "module :", nullptr));
    } // retranslateUi

};

namespace Ui {
    class affichage_etudiant_module: public Ui_affichage_etudiant_module {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_AFFICHAGE_ETUDIANT_MODULE_H
