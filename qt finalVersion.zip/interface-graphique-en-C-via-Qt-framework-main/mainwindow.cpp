#include "mainwindow.h"
#include "ui_mainwindow.h"
#include"espace_admin.h"
#include"espace_prf.h"
#include <QSqlQuery>
#include <QSqlError>
#include <QDebug>
#include <QSqlRecord>
#include <QFileInfo>

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);

}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::on_espace_admin_clicked()
{
    this->close();
    espace_admin *mydialog = new espace_admin(this );
    mydialog->show();
}


void MainWindow::on_espace_prf_clicked()
{
    this->close();
    espace_prf *mydialog = new espace_prf(this );
    mydialog->show();
}

