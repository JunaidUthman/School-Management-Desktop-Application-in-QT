#ifndef TRAITEMENT_PROF_H
#define TRAITEMENT_PROF_H

#include <QDialog>
#include<QSqlDatabase>

namespace Ui {
class traitement_prof;
}

class traitement_prof : public QDialog
{
    Q_OBJECT

public:
    explicit traitement_prof(QString module,QWidget *parent = nullptr);
    ~traitement_prof();

private slots:
    void on_pushButton_clicked();

    void on_pushButton_2_clicked();

    void on_pushButton_3_clicked();

    void on_pushButton_4_clicked();

    void on_lsi1_2_clicked();

    void on_pushButton_5_clicked();

    void on_lsi2_2_clicked();

    void on_lsi3_2_clicked();

    void on_pushButton_6_clicked();

private:
    Ui::traitement_prof *ui;
    QString module;
    void loadStudentData(const QString &level);
    QSqlDatabase mydb;
};

#endif // TRAITEMENT_PROF_H
