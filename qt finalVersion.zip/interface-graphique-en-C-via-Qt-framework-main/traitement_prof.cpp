#include "traitement_prof.h"
#include "ui_traitement_prof.h"
#include "espace_prf.h"
#include"MainWindow.h"
#include <QMessageBox>
#include <QDebug>
#include <QSqlQuery>
#include <QInputDialog>
#include <QSqlQueryModel>
#include <QSqlError>
#include<QGraphicsBlurEffect>


traitement_prof::traitement_prof(QString module,QWidget *parent)
    : QDialog(parent)
    , ui(new Ui::traitement_prof) , module(module)
{
    ui->setupUi(this);
    ui->stackedWidget->setCurrentIndex(0);
    qDebug() << "Module Professeur (constructeur) : " << module;
    QPixmap pix2("C:/Users/DELL/Desktop/projet QT complet/Nouveau dossier/pexels-serpstat-177219-572056.jpg");

    QPixmap pix("C:/Users/DELL/Desktop/projet QT complet/Nouveau dossier/FST-Tanger-modified.png");
    ui->label_3->setPixmap(pix.scaled(100,100,Qt::KeepAspectRatio));

    // Ajuster la taille de l'image selon vos besoins
    QPixmap scaledPix = pix2.scaled(800, 800, Qt::KeepAspectRatio);

    // Appliquer un effet de flou
    QGraphicsBlurEffect *blurEffect = new QGraphicsBlurEffect();
    blurEffect->setBlurRadius(15); // Ajuster le rayon pour augmenter/diminuer le flou

    // Créer un QLabel pour afficher l'image
    QLabel *label = ui->label;
    label->setPixmap(scaledPix);

    // Appliquer l'effet au QLabel
    label->setGraphicsEffect(blurEffect);

    // Connexion à la base de données SQLite
    mydb = QSqlDatabase::addDatabase("QSQLITE");
    mydb.setDatabaseName("C:/Users/pc/Downloads/Desktop/Documents/login_espace_admin_prf/database_login/database_login/new_db/lsidb.db");

    if (!mydb.open()) {
        qDebug() << "Error: Unable to connect to database!";
    } else {
        qDebug() << "Database connected successfully!";
    }
}

traitement_prof::~traitement_prof()
{
    delete ui;
}

void traitement_prof::loadStudentData(const QString &level)
{
    // Vérification de l'initialisation de moduleProf
    if (module.isEmpty()) {
        QMessageBox::critical(this, "Error", "Le module n'a pas été correctement initialisé.");
        qDebug() << "Erreur : moduleProf est vide.";
        return;
    }

    qDebug() << "Module Professeur (loadStudentData) : " << module;

    ui->stackedWidget->setCurrentIndex(2); // Passer à la page 2

    if (!mydb.isOpen()) {
        QMessageBox::critical(this, "Database Error", "La base de données n'est pas accessible.");
        return;
    }

    // Récupérer l'ID du module basé sur le nom du module du professeur
    QSqlQuery moduleQuery(mydb);
    moduleQuery.prepare(R"(
        SELECT cid FROM modules WHERE nom =:module
    )");
    moduleQuery.bindValue(":module",module); // Utiliser le nom du module du professeur

    int moduleId = -1;
    if (moduleQuery.exec() && moduleQuery.next()) {
        moduleId = moduleQuery.value(0).toInt(); // Obtenir l'ID du module
    } else {
        QMessageBox::critical(this, "Error", "Le module n'a pas été trouvé dans la base de données.");
        qDebug() << "Le module n'a pas été trouvé pour : " << module;
        return;
    }

    // Requête avec jointure entre étudiants et inscription
    QSqlQuery query(mydb);
    query.prepare(R"(
        SELECT students.id, students.nom, students.prenom, students.cne,
           students.adresse, students.date_naissance, students.diplome_obtenu, students.niveau_etudes,
           inscription.note
        FROM students
        JOIN inscription ON students.id = inscription.id_etudiant
        WHERE students.niveau_etudes = :niveau
        AND inscription.id_module = :moduleId
    )");
    query.bindValue(":niveau", level);
    query.bindValue(":moduleId", moduleId); // Utiliser l'ID du module

    if (query.exec()) {
        QSqlQueryModel *model = new QSqlQueryModel(this);
        model->setQuery(query);
        ui->studentsTableView_2->setModel(model);
        ui->studentsTableView_2->resizeColumnsToContents();
        ui->studentsTableView_2->horizontalHeader()->setStretchLastSection(true);
        ui->studentsTableView_2->verticalHeader()->setVisible(false);

        // Ajouter la colonne "Modifier"
        int columnCount = model->columnCount();
        model->insertColumn(columnCount);
        ui->studentsTableView_2->setColumnWidth(columnCount, 100);
        // Définir le nom de la colonne "Modifier"
        model->setHeaderData(columnCount, Qt::Horizontal, "Modifier");

        // Remplir la colonne "Modifier" avec des boutons
        for (int row = 0; row < model->rowCount(); ++row) {
            QPushButton *modifyButton = new QPushButton("Modifier");
            connect(modifyButton, &QPushButton::clicked, this, [=]() {
                // Récupérer l'ID de l'étudiant et la note actuelle
                int studentId = model->data(model->index(row, 0)).toInt();
                double currentNote = model->data(model->index(row, 8)).toDouble(); // La colonne "note"

                // Demander la nouvelle note
                bool ok;
                double newNote = QInputDialog::getDouble(this, "Modifier la note",
                                                         "Nouvelle note :", currentNote, 0, 20, 1, &ok);
                if (ok) {
                    // Mettre à jour la note dans la base de données
                    QSqlQuery updateQuery(mydb);
                    updateQuery.prepare(R"(
                        UPDATE inscription
                        SET note = :note
                        WHERE id_etudiant = :studentId AND id_module = :moduleId
                    )");
                    updateQuery.bindValue(":note", newNote);
                    updateQuery.bindValue(":studentId", studentId);
                    updateQuery.bindValue(":moduleId", moduleId);
                    if (updateQuery.exec()) {
                        QMessageBox::information(this, "Success", "Note mise à jour avec succès.");
                        loadStudentData(level); // Recharger les données
                    } else {
                        QMessageBox::critical(this, "Error", "Impossible de mettre à jour la note.");
                    }
                }
            });

            ui->studentsTableView_2->setIndexWidget(model->index(row, columnCount), modifyButton);
        }

        qDebug() << "Data loaded successfully for level " << level;
    } else {
        QMessageBox::critical(this, "Error", "Impossible d'exécuter la requête : " + query.lastError().text());
    }
}

void traitement_prof::on_pushButton_clicked()
{
    loadStudentData("LSI1");
}


void traitement_prof::on_pushButton_2_clicked()
{
    loadStudentData("LSI2");
}


void traitement_prof::on_pushButton_3_clicked()
{
    loadStudentData("LSI3");
}


void traitement_prof::on_pushButton_4_clicked()
{
    MainWindow *newMainWindow = new MainWindow();
    newMainWindow->show(); // Show the new main window

    close(); // Close the dialog
}



void traitement_prof::on_lsi1_2_clicked()
{
    QString imagePath = "C:/Users/DELL/Desktop/projet QT complet/Nouveau dossier/lsi1.png"; // Remplacez par le chemin réel de l'image

    // Récupérer le QStackedWidget
    QStackedWidget* stackedWidget = ui->stackedWidget;

    // Accéder à la page spécifique (page 4 dans ce cas, index 3 car l'index commence à 0)
    QWidget* page4 = stackedWidget->widget(1);  // index 3 correspond à la 4ème page

    // Rechercher le QLabel dans cette page (assurez-vous que l'objet QLabel dans cette page s'appelle label_image)
    QLabel* labelImage = page4->findChild<QLabel*>("label_image");

    // Vérifier si le QLabel a été trouvé
    if (labelImage) {
        // Charger l'image dans le QPixmap
        QPixmap pixmap(imagePath);

        // Vérifier si l'image a bien été chargée
        if (!pixmap.isNull()) {
            // Afficher l'image dans le QLabel
            labelImage->setPixmap(pixmap);
            labelImage->setScaledContents(true);  // Adapter l'image à la taille du QLabel
        } else {
            // Afficher un message d'erreur si l'image n'a pas pu être chargée
            QMessageBox::warning(this, "Erreur", "Image non trouvée !");
        }
    } else {
        // Afficher un message d'erreur si le QLabel n'a pas été trouvé
        QMessageBox::warning(this, "Erreur", "Le QLabel pour afficher l'image n'a pas été trouvé !");
    }
}


void traitement_prof::on_pushButton_5_clicked()
{
    ui->stackedWidget->setCurrentIndex(1);
}


void traitement_prof::on_lsi2_2_clicked()
{
    QString imagePath = "C:/Users/DELL/Desktop/projet QT complet/Nouveau dossier/lsi2.png"; // Remplacez par le chemin réel de l'image

    // Récupérer le QStackedWidget
    QStackedWidget* stackedWidget = ui->stackedWidget;

    // Accéder à la page spécifique (page 4 dans ce cas, index 3 car l'index commence à 0)
    QWidget* page4 = stackedWidget->widget(1);  // index 3 correspond à la 4ème page

    // Rechercher le QLabel dans cette page (assurez-vous que l'objet QLabel dans cette page s'appelle label_image)
    QLabel* labelImage = page4->findChild<QLabel*>("label_image");

    // Vérifier si le QLabel a été trouvé
    if (labelImage) {
        // Charger l'image dans le QPixmap
        QPixmap pixmap(imagePath);

        // Vérifier si l'image a bien été chargée
        if (!pixmap.isNull()) {
            // Afficher l'image dans le QLabel
            labelImage->setPixmap(pixmap);
            labelImage->setScaledContents(true);  // Adapter l'image à la taille du QLabel
        } else {
            // Afficher un message d'erreur si l'image n'a pas pu être chargée
            QMessageBox::warning(this, "Erreur", "Image non trouvée !");
        }
    } else {
        // Afficher un message d'erreur si le QLabel n'a pas été trouvé
        QMessageBox::warning(this, "Erreur", "Le QLabel pour afficher l'image n'a pas été trouvé !");
    }
}


void traitement_prof::on_lsi3_2_clicked()
{
    QString imagePath = "C:/Users/DELL/Desktop/projet QT complet/Nouveau dossier/lsi3.png"; // Remplacez par le chemin réel de l'image

    // Récupérer le QStackedWidget
    QStackedWidget* stackedWidget = ui->stackedWidget;

    // Accéder à la page spécifique (page 4 dans ce cas, index 3 car l'index commence à 0)
    QWidget* page4 = stackedWidget->widget(1);  // index 3 correspond à la 4ème page

    // Rechercher le QLabel dans cette page (assurez-vous que l'objet QLabel dans cette page s'appelle label_image)
    QLabel* labelImage = page4->findChild<QLabel*>("label_image");

    // Vérifier si le QLabel a été trouvé
    if (labelImage) {
        // Charger l'image dans le QPixmap
        QPixmap pixmap(imagePath);

        // Vérifier si l'image a bien été chargée
        if (!pixmap.isNull()) {
            // Afficher l'image dans le QLabel
            labelImage->setPixmap(pixmap);
            labelImage->setScaledContents(true);  // Adapter l'image à la taille du QLabel
        } else {
            // Afficher un message d'erreur si l'image n'a pas pu être chargée
            QMessageBox::warning(this, "Erreur", "Image non trouvée !");
        }
    } else {
        // Afficher un message d'erreur si le QLabel n'a pas été trouvé
        QMessageBox::warning(this, "Erreur", "Le QLabel pour afficher l'image n'a pas été trouvé !");
    }
}


void traitement_prof::on_pushButton_6_clicked()
{
    this->close();
}

