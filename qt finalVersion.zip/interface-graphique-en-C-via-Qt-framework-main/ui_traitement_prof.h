/********************************************************************************
** Form generated from reading UI file 'traitement_prof.ui'
**
** Created by: Qt User Interface Compiler version 6.8.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_TRAITEMENT_PROF_H
#define UI_TRAITEMENT_PROF_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QStackedWidget>
#include <QtWidgets/QTableView>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_traitement_prof
{
public:
    QWidget *widget;
    QPushButton *pushButton;
    QPushButton *pushButton_2;
    QPushButton *pushButton_3;
    QPushButton *pushButton_4;
    QPushButton *pushButton_5;
    QLabel *label_3;
    QPushButton *pushButton_6;
    QStackedWidget *stackedWidget;
    QWidget *page;
    QLabel *label;
    QLabel *label_6;
    QWidget *page_3;
    QLabel *label_image;
    QPushButton *lsi1_2;
    QPushButton *lsi2_2;
    QPushButton *lsi3_2;
    QLabel *label_2;
    QWidget *page_2;
    QTableView *studentsTableView_2;
    QLabel *label_4;
    QWidget *widget_2;
    QLabel *label_5;

    void setupUi(QDialog *traitement_prof)
    {
        if (traitement_prof->objectName().isEmpty())
            traitement_prof->setObjectName("traitement_prof");
        traitement_prof->resize(772, 511);
        widget = new QWidget(traitement_prof);
        widget->setObjectName("widget");
        widget->setGeometry(QRect(0, 0, 141, 511));
        widget->setStyleSheet(QString::fromUtf8("background-color: #2980B9;\n"
"border-color:#2980B9;\n"
"\n"
"\n"
""));
        pushButton = new QPushButton(widget);
        pushButton->setObjectName("pushButton");
        pushButton->setGeometry(QRect(0, 170, 131, 51));
        pushButton->setStyleSheet(QString::fromUtf8("/* Boutons de la sidebar */\n"
"\n"
"    background-color: #3498DB; /* Bleu l\303\251g\303\250rement plus clair */\n"
"    color: #FFFFFF; /* Texte blanc */\n"
"    font-weight: bold; /* Texte en gras */\n"
"    border: none; /* Pas de bordure */\n"
"    border-radius: 6px; /* Coins arrondis */\n"
"    padding: 8px 15px; /* Espacement int\303\251rieur */\n"
"    margin: 5px 10px; /* Espacement externe pour espacer les boutons */\n"
"    text-align: center; /* Alignement \303\240 gauche pour un style de menu */\n"
"font-size:11px;\n"
""));
        pushButton_2 = new QPushButton(widget);
        pushButton_2->setObjectName("pushButton_2");
        pushButton_2->setGeometry(QRect(0, 230, 131, 51));
        pushButton_2->setStyleSheet(QString::fromUtf8("/* Boutons de la sidebar */\n"
"\n"
"    background-color: #3498DB; /* Bleu l\303\251g\303\250rement plus clair */\n"
"    color: #FFFFFF; /* Texte blanc */\n"
"    font-weight: bold; /* Texte en gras */\n"
"    border: none; /* Pas de bordure */\n"
"    border-radius: 6px; /* Coins arrondis */\n"
"    padding: 8px 15px; /* Espacement int\303\251rieur */\n"
"    margin: 5px 10px; /* Espacement externe pour espacer les boutons */\n"
"    text-align: center; /* Alignement \303\240 gauche pour un style de menu */\n"
"font-size:11px;\n"
""));
        pushButton_3 = new QPushButton(widget);
        pushButton_3->setObjectName("pushButton_3");
        pushButton_3->setGeometry(QRect(0, 290, 131, 51));
        pushButton_3->setStyleSheet(QString::fromUtf8("/* Boutons de la sidebar */\n"
"\n"
"    background-color: #3498DB; /* Bleu l\303\251g\303\250rement plus clair */\n"
"    color: #FFFFFF; /* Texte blanc */\n"
"    font-weight: bold; /* Texte en gras */\n"
"    border: none; /* Pas de bordure */\n"
"    border-radius: 6px; /* Coins arrondis */\n"
"    padding: 8px 15px; /* Espacement int\303\251rieur */\n"
"    margin: 5px 10px; /* Espacement externe pour espacer les boutons */\n"
"    text-align: center; /* Alignement \303\240 gauche pour un style de menu */\n"
"font-size:11px;\n"
""));
        pushButton_4 = new QPushButton(widget);
        pushButton_4->setObjectName("pushButton_4");
        pushButton_4->setGeometry(QRect(0, 430, 141, 41));
        pushButton_4->setStyleSheet(QString::fromUtf8("/* Boutons de la sidebar */\n"
"\n"
"    background-color: green; /* Bleu l\303\251g\303\250rement plus clair */\n"
"    color: #FFFFFF; /* Texte blanc */\n"
"    font-weight: bold; /* Texte en gras */\n"
"    border: none; /* Pas de bordure */\n"
"    border-radius: 6px; /* Coins arrondis */\n"
"    padding: 8px 15px; /* Espacement int\303\251rieur */\n"
"    margin: 5px 10px; /* Espacement externe pour espacer les boutons */\n"
"    text-align: center; /* Alignement \303\240 gauche pour un style de menu */\n"
"font-size:11px;\n"
""));
        pushButton_5 = new QPushButton(widget);
        pushButton_5->setObjectName("pushButton_5");
        pushButton_5->setGeometry(QRect(0, 350, 131, 51));
        pushButton_5->setStyleSheet(QString::fromUtf8("/* Boutons de la sidebar */\n"
"\n"
"    background-color: #3498DB; /* Bleu l\303\251g\303\250rement plus clair */\n"
"    color: #FFFFFF; /* Texte blanc */\n"
"    font-weight: bold; /* Texte en gras */\n"
"    border: none; /* Pas de bordure */\n"
"    border-radius: 6px; /* Coins arrondis */\n"
"    padding: 8px 15px; /* Espacement int\303\251rieur */\n"
"    margin: 5px 10px; /* Espacement externe pour espacer les boutons */\n"
"    text-align: center; /* Alignement \303\240 gauche pour un style de menu */\n"
"font-size:11px;\n"
""));
        label_3 = new QLabel(widget);
        label_3->setObjectName("label_3");
        label_3->setGeometry(QRect(20, 20, 131, 111));
        pushButton_6 = new QPushButton(widget);
        pushButton_6->setObjectName("pushButton_6");
        pushButton_6->setGeometry(QRect(0, 470, 141, 41));
        pushButton_6->setStyleSheet(QString::fromUtf8("/* Boutons de la sidebar */\n"
"\n"
"    background-color: red; /* Bleu l\303\251g\303\250rement plus clair */\n"
"    color: #FFFFFF; /* Texte blanc */\n"
"    font-weight: bold; /* Texte en gras */\n"
"    border: none; /* Pas de bordure */\n"
"    border-radius: 6px; /* Coins arrondis */\n"
"    padding: 8px 15px; /* Espacement int\303\251rieur */\n"
"    margin: 5px 10px; /* Espacement externe pour espacer les boutons */\n"
"    text-align: center; /* Alignement \303\240 gauche pour un style de menu */\n"
"font-size:11px;\n"
""));
        stackedWidget = new QStackedWidget(traitement_prof);
        stackedWidget->setObjectName("stackedWidget");
        stackedWidget->setGeometry(QRect(140, 100, 631, 411));
        stackedWidget->setStyleSheet(QString::fromUtf8("background-color: #F5F5F5;"));
        page = new QWidget();
        page->setObjectName("page");
        label = new QLabel(page);
        label->setObjectName("label");
        label->setGeometry(QRect(0, 0, 631, 411));
        label_6 = new QLabel(page);
        label_6->setObjectName("label_6");
        label_6->setGeometry(QRect(180, 10, 241, 61));
        label_6->setStyleSheet(QString::fromUtf8("font-size: 25px; /* Taille de police */\n"
"    font-weight: bold; /* Texte en gras */\n"
"    color: #2980B9; /* Couleur du texte */\n"
"    text-align: center; /* Centrer le texte */\n"
"    padding: 10px; /* Espacement int\303\251rieur */\n"
" \n"
"    border-radius: 10px; /* Coins arrondis */"));
        stackedWidget->addWidget(page);
        page_3 = new QWidget();
        page_3->setObjectName("page_3");
        label_image = new QLabel(page_3);
        label_image->setObjectName("label_image");
        label_image->setGeometry(QRect(20, 130, 591, 271));
        lsi1_2 = new QPushButton(page_3);
        lsi1_2->setObjectName("lsi1_2");
        lsi1_2->setGeometry(QRect(40, 80, 131, 41));
        lsi1_2->setStyleSheet(QString::fromUtf8("/* Boutons de la sidebar */\n"
"\n"
"    background-color: #3498DB; /* Bleu l\303\251g\303\250rement plus clair */\n"
"    color: #FFFFFF; /* Texte blanc */\n"
"    font-weight: bold; /* Texte en gras */\n"
"    border: none; /* Pas de bordure */\n"
"    border-radius: 6px; /* Coins arrondis */\n"
"    padding: 8px 15px; /* Espacement int\303\251rieur */\n"
"    margin: 5px 10px; /* Espacement externe pour espacer les boutons */\n"
"    text-align: center; /* Alignement \303\240 gauche pour un style de menu */\n"
"font-size:11px;\n"
""));
        lsi2_2 = new QPushButton(page_3);
        lsi2_2->setObjectName("lsi2_2");
        lsi2_2->setGeometry(QRect(250, 80, 131, 41));
        lsi2_2->setStyleSheet(QString::fromUtf8("/* Boutons de la sidebar */\n"
"\n"
"    background-color: #3498DB; /* Bleu l\303\251g\303\250rement plus clair */\n"
"    color: #FFFFFF; /* Texte blanc */\n"
"    font-weight: bold; /* Texte en gras */\n"
"    border: none; /* Pas de bordure */\n"
"    border-radius: 6px; /* Coins arrondis */\n"
"    padding: 8px 15px; /* Espacement int\303\251rieur */\n"
"    margin: 5px 10px; /* Espacement externe pour espacer les boutons */\n"
"    text-align: center; /* Alignement \303\240 gauche pour un style de menu */\n"
"font-size:11px;\n"
""));
        lsi3_2 = new QPushButton(page_3);
        lsi3_2->setObjectName("lsi3_2");
        lsi3_2->setGeometry(QRect(440, 80, 131, 41));
        lsi3_2->setStyleSheet(QString::fromUtf8("/* Boutons de la sidebar */\n"
"\n"
"    background-color: #3498DB; /* Bleu l\303\251g\303\250rement plus clair */\n"
"    color: #FFFFFF; /* Texte blanc */\n"
"    font-weight: bold; /* Texte en gras */\n"
"    border: none; /* Pas de bordure */\n"
"    border-radius: 6px; /* Coins arrondis */\n"
"    padding: 8px 15px; /* Espacement int\303\251rieur */\n"
"    margin: 5px 10px; /* Espacement externe pour espacer les boutons */\n"
"    text-align: center; /* Alignement \303\240 gauche pour un style de menu */\n"
"font-size:11px;\n"
""));
        label_2 = new QLabel(page_3);
        label_2->setObjectName("label_2");
        label_2->setGeometry(QRect(180, 10, 231, 51));
        label_2->setStyleSheet(QString::fromUtf8("font-size: 25px; /* Taille de police */\n"
"    font-weight: bold; /* Texte en gras */\n"
"    color: #2980B9; /* Couleur du texte */\n"
"    text-align: center; /* Centrer le texte */\n"
"    padding: 10px; /* Espacement int\303\251rieur */\n"
" \n"
"    border-radius: 10px; /* Coins arrondis */\n"
""));
        stackedWidget->addWidget(page_3);
        page_2 = new QWidget();
        page_2->setObjectName("page_2");
        studentsTableView_2 = new QTableView(page_2);
        studentsTableView_2->setObjectName("studentsTableView_2");
        studentsTableView_2->setGeometry(QRect(20, 70, 601, 311));
        studentsTableView_2->setStyleSheet(QString::fromUtf8("\n"
"    QTableView#studentsTableView_2 {\n"
"        background-color: #f9f9f9; /* Couleur de fond claire */\n"
"        border: 1px solid #cccccc; /* Bordure grise */\n"
"        gridline-color: #e0e0e0; /* Couleur des lignes de la grille */\n"
"        selection-background-color: #4CAF50; /* Fond vert pour les \303\251l\303\251ments s\303\251lectionn\303\251s */\n"
"        selection-color: white; /* Texte blanc pour les \303\251l\303\251ments s\303\251lectionn\303\251s */\n"
"        font-family: Arial, sans-serif; /* Police */\n"
"        font-size: 14px; /* Taille de la police */\n"
"    }\n"
"\n"
"    QHeaderView::section {\n"
"        background-color: rgb(69, 128, 255); /* Fond bleu pour les en-t\303\252tes */\n"
"        color: white; /* Texte blanc */\n"
"        font-weight: bold; /* Texte en gras */\n"
"        border: 1px solid #cccccc; /* Bordure des en-t\303\252tes */\n"
"        padding: 4px;\n"
"    }\n"
"\n"
"    QTableView::item {\n"
"        padding: 5px; /* Espacement \303\240 l'int\303\251"
                        "rieur des cellules */\n"
"    }\n"
"\n"
"    QTableView::item:hover {\n"
"        background-color: #f1f1f1; /* Couleur claire au survol */\n"
"    }\n"
"\n"
"    QTableView::item:selected {\n"
"        background-color: rgb(115, 145, 255) ; /* Couleur verte pour la s\303\251lection */\n"
"        color: white; /* Texte blanc */\n"
"    }\n"
"\n"
""));
        label_4 = new QLabel(page_2);
        label_4->setObjectName("label_4");
        label_4->setGeometry(QRect(180, 10, 231, 41));
        label_4->setStyleSheet(QString::fromUtf8("font-size: 25px; /* Taille de police */\n"
"    font-weight: bold; /* Texte en gras */\n"
"    color: #2980B9; /* Couleur du texte */\n"
"    text-align: center; /* Centrer le texte */\n"
"    padding: 10px; /* Espacement int\303\251rieur */\n"
" \n"
"    border-radius: 10px; /* Coins arrondis */\n"
""));
        stackedWidget->addWidget(page_2);
        widget_2 = new QWidget(traitement_prof);
        widget_2->setObjectName("widget_2");
        widget_2->setGeometry(QRect(140, 0, 631, 101));
        widget_2->setStyleSheet(QString::fromUtf8("background-color: #2980B9;\n"
"border-color:#2980B9;"));
        label_5 = new QLabel(widget_2);
        label_5->setObjectName("label_5");
        label_5->setGeometry(QRect(200, 20, 201, 51));
        label_5->setStyleSheet(QString::fromUtf8("font-size: 25px; /* Taille de police */\n"
"    font-weight: bold; /* Texte en gras */\n"
"    color: white; /* Couleur du texte */\n"
"    text-align: center; /* Centrer le texte */\n"
"    padding: 10px; /* Espacement int\303\251rieur */\n"
" \n"
"    border-radius: 10px; /* Coins arrondis */\n"
""));

        retranslateUi(traitement_prof);

        stackedWidget->setCurrentIndex(1);


        QMetaObject::connectSlotsByName(traitement_prof);
    } // setupUi

    void retranslateUi(QDialog *traitement_prof)
    {
        traitement_prof->setWindowTitle(QCoreApplication::translate("traitement_prof", "Dialog", nullptr));
        pushButton->setText(QCoreApplication::translate("traitement_prof", "LSI1", nullptr));
        pushButton_2->setText(QCoreApplication::translate("traitement_prof", "LSI2", nullptr));
        pushButton_3->setText(QCoreApplication::translate("traitement_prof", "LSI3", nullptr));
        pushButton_4->setText(QCoreApplication::translate("traitement_prof", "Page initiale", nullptr));
        pushButton_5->setText(QCoreApplication::translate("traitement_prof", "Emploit", nullptr));
        label_3->setText(QString());
        pushButton_6->setText(QCoreApplication::translate("traitement_prof", "Exit", nullptr));
        label->setText(QString());
        label_6->setText(QCoreApplication::translate("traitement_prof", "Espace Professeur", nullptr));
        label_image->setText(QString());
        lsi1_2->setText(QCoreApplication::translate("traitement_prof", "LSI1", nullptr));
        lsi2_2->setText(QCoreApplication::translate("traitement_prof", "LSI2", nullptr));
        lsi3_2->setText(QCoreApplication::translate("traitement_prof", "LSI3", nullptr));
        label_2->setText(QCoreApplication::translate("traitement_prof", "Emploi du Temps", nullptr));
        label_4->setText(QCoreApplication::translate("traitement_prof", "Liste D'Etudiants", nullptr));
        label_5->setText(QCoreApplication::translate("traitement_prof", "FST TANGER", nullptr));
    } // retranslateUi

};

namespace Ui {
    class traitement_prof: public Ui_traitement_prof {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_TRAITEMENT_PROF_H
