#include "traitement_espace_admin.h"


traitement_espace_admin::traitement_espace_admin(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::traitement_espace_admin)
{
    ui->setupUi(this);
    qDebug() << "traitement_espace_admin created";
}

traitement_espace_admin::~traitement_espace_admin()
{
    delete ui;
    qDebug() << "traitement_espace_admin destroyed";
}
