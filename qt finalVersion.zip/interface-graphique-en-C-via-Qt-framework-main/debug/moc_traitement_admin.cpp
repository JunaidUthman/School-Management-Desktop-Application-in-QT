/****************************************************************************
** Meta object code from reading C++ file 'traitement_admin.h'
**
** Created by: The Qt Meta Object Compiler version 68 (Qt 6.8.1)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../traitement_admin.h"
#include <QtCore/qmetatype.h>

#include <QtCore/qtmochelpers.h>

#include <memory>


#include <QtCore/qxptype_traits.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'traitement_admin.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 68
#error "This file was generated using the moc from 6.8.1. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

#ifndef Q_CONSTINIT
#define Q_CONSTINIT
#endif

QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
QT_WARNING_DISABLE_GCC("-Wuseless-cast")
namespace {
struct qt_meta_tag_ZN16traitement_adminE_t {};
} // unnamed namespace


#ifdef QT_MOC_HAS_STRINGDATA
static constexpr auto qt_meta_stringdata_ZN16traitement_adminE = QtMocHelpers::stringData(
    "traitement_admin",
    "on_menue_clicked",
    "",
    "on_etudiant_clicked",
    "on_pushButton_4_clicked",
    "on_page_initiale_clicked",
    "on_lsi1_clicked",
    "on_lsi2_clicked",
    "on_lsi3_clicked",
    "on_professeurs_clicked",
    "on_modules_clicked",
    "on_pushButton_clicked",
    "on_butnenr_clicked",
    "on_ajouter_prof_clicked",
    "on_btnenregistrer_clicked",
    "on_btn5_clicked",
    "on_lsi1_2_clicked",
    "on_lsi2_2_clicked",
    "on_lsi3_2_clicked",
    "on_label_2_linkActivated",
    "link",
    "on_label_22_linkActivated"
);
#else  // !QT_MOC_HAS_STRINGDATA
#error "qtmochelpers.h not found or too old."
#endif // !QT_MOC_HAS_STRINGDATA

Q_CONSTINIT static const uint qt_meta_data_ZN16traitement_adminE[] = {

 // content:
      12,       // revision
       0,       // classname
       0,    0, // classinfo
      19,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags, initial metatype offsets
       1,    0,  128,    2, 0x08,    1 /* Private */,
       3,    0,  129,    2, 0x08,    2 /* Private */,
       4,    0,  130,    2, 0x08,    3 /* Private */,
       5,    0,  131,    2, 0x08,    4 /* Private */,
       6,    0,  132,    2, 0x08,    5 /* Private */,
       7,    0,  133,    2, 0x08,    6 /* Private */,
       8,    0,  134,    2, 0x08,    7 /* Private */,
       9,    0,  135,    2, 0x08,    8 /* Private */,
      10,    0,  136,    2, 0x08,    9 /* Private */,
      11,    0,  137,    2, 0x08,   10 /* Private */,
      12,    0,  138,    2, 0x08,   11 /* Private */,
      13,    0,  139,    2, 0x08,   12 /* Private */,
      14,    0,  140,    2, 0x08,   13 /* Private */,
      15,    0,  141,    2, 0x08,   14 /* Private */,
      16,    0,  142,    2, 0x08,   15 /* Private */,
      17,    0,  143,    2, 0x08,   16 /* Private */,
      18,    0,  144,    2, 0x08,   17 /* Private */,
      19,    1,  145,    2, 0x08,   18 /* Private */,
      21,    1,  148,    2, 0x08,   20 /* Private */,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::QString,   20,
    QMetaType::Void, QMetaType::QString,   20,

       0        // eod
};

Q_CONSTINIT const QMetaObject traitement_admin::staticMetaObject = { {
    QMetaObject::SuperData::link<QDialog::staticMetaObject>(),
    qt_meta_stringdata_ZN16traitement_adminE.offsetsAndSizes,
    qt_meta_data_ZN16traitement_adminE,
    qt_static_metacall,
    nullptr,
    qt_incomplete_metaTypeArray<qt_meta_tag_ZN16traitement_adminE_t,
        // Q_OBJECT / Q_GADGET
        QtPrivate::TypeAndForceComplete<traitement_admin, std::true_type>,
        // method 'on_menue_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_etudiant_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_pushButton_4_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_page_initiale_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_lsi1_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_lsi2_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_lsi3_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_professeurs_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_modules_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_pushButton_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_butnenr_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_ajouter_prof_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_btnenregistrer_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_btn5_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_lsi1_2_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_lsi2_2_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_lsi3_2_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_label_2_linkActivated'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<const QString &, std::false_type>,
        // method 'on_label_22_linkActivated'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<const QString &, std::false_type>
    >,
    nullptr
} };

void traitement_admin::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    auto *_t = static_cast<traitement_admin *>(_o);
    if (_c == QMetaObject::InvokeMetaMethod) {
        switch (_id) {
        case 0: _t->on_menue_clicked(); break;
        case 1: _t->on_etudiant_clicked(); break;
        case 2: _t->on_pushButton_4_clicked(); break;
        case 3: _t->on_page_initiale_clicked(); break;
        case 4: _t->on_lsi1_clicked(); break;
        case 5: _t->on_lsi2_clicked(); break;
        case 6: _t->on_lsi3_clicked(); break;
        case 7: _t->on_professeurs_clicked(); break;
        case 8: _t->on_modules_clicked(); break;
        case 9: _t->on_pushButton_clicked(); break;
        case 10: _t->on_butnenr_clicked(); break;
        case 11: _t->on_ajouter_prof_clicked(); break;
        case 12: _t->on_btnenregistrer_clicked(); break;
        case 13: _t->on_btn5_clicked(); break;
        case 14: _t->on_lsi1_2_clicked(); break;
        case 15: _t->on_lsi2_2_clicked(); break;
        case 16: _t->on_lsi3_2_clicked(); break;
        case 17: _t->on_label_2_linkActivated((*reinterpret_cast< std::add_pointer_t<QString>>(_a[1]))); break;
        case 18: _t->on_label_22_linkActivated((*reinterpret_cast< std::add_pointer_t<QString>>(_a[1]))); break;
        default: ;
        }
    }
}

const QMetaObject *traitement_admin::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *traitement_admin::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_ZN16traitement_adminE.stringdata0))
        return static_cast<void*>(this);
    return QDialog::qt_metacast(_clname);
}

int traitement_admin::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QDialog::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 19)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 19;
    }
    if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 19)
            *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType();
        _id -= 19;
    }
    return _id;
}
QT_WARNING_POP
