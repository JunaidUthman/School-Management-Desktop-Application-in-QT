/********************************************************************************
** Form generated from reading UI file 'affichage_etudiants.ui'
**
** Created by: Qt User Interface Compiler version 6.8.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_AFFICHAGE_ETUDIANTS_H
#define UI_AFFICHAGE_ETUDIANTS_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QTableWidget>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_affichage_etudiants
{
public:
    QWidget *widget_2;
    QTableWidget *etudiantTable;

    void setupUi(QDialog *affichage_etudiants)
    {
        if (affichage_etudiants->objectName().isEmpty())
            affichage_etudiants->setObjectName("affichage_etudiants");
        affichage_etudiants->resize(401, 303);
        widget_2 = new QWidget(affichage_etudiants);
        widget_2->setObjectName("widget_2");
        widget_2->setGeometry(QRect(0, 0, 401, 301));
        etudiantTable = new QTableWidget(widget_2);
        etudiantTable->setObjectName("etudiantTable");
        etudiantTable->setGeometry(QRect(0, -9, 401, 311));
        etudiantTable->setStyleSheet(QString::fromUtf8("background-color:#F2F6FA;"));

        retranslateUi(affichage_etudiants);

        QMetaObject::connectSlotsByName(affichage_etudiants);
    } // setupUi

    void retranslateUi(QDialog *affichage_etudiants)
    {
        affichage_etudiants->setWindowTitle(QCoreApplication::translate("affichage_etudiants", "Dialog", nullptr));
    } // retranslateUi

};

namespace Ui {
    class affichage_etudiants: public Ui_affichage_etudiants {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_AFFICHAGE_ETUDIANTS_H
