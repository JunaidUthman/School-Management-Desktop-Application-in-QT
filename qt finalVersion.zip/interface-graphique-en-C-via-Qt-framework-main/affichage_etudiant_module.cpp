#include "affichage_etudiant_module.h"
#include "ui_affichage_etudiant_module.h"
#include <QSqlError>
#include <QSqlQuery>
#include<QPushButton>


affichage_etudiant_module::affichage_etudiant_module(const int id_module , QWidget *parent)
    : QDialog(parent) , ui(new Ui::affichage_etudiant_module) , id_module(id_module)
{
    ui->setupUi(this);
    qDebug() << id_module;
    QString file = "C:/Users/pc/Downloads/Desktop/Documents/login_espace_admin_prf/database_login/database_login/new_db/lsidb.db";
    db_connection = QSqlDatabase::addDatabase("QSQLITE");
    db_connection.setDatabaseName(file);

    // Vérification de la connexion
    if (db_connection.open()){
        qDebug() << "db is connected";
    } else {
        qDebug() << "db is not connected: " << db_connection.lastError().text();
    }
    QSqlQuery query_nom_module;
    query_nom_module.prepare("SELECT nom FROM modules WHERE cid = :id_module");
    query_nom_module.bindValue(":id_module", id_module);

    if (query_nom_module.exec()) {
        if (query_nom_module.next()) { // Avancer au premier résultat
            QString nom_module = query_nom_module.value("nom").toString();
            ui->module->setText(nom_module); // Met à jour l'UI
            qDebug() << "Le nom du module est :" << nom_module;
        } else {
            qDebug() << "Aucun module trouvé avec id_module =" << id_module;
        }
    } else {
        qDebug() << "Erreur dans l'exécution de la requête :"
                 << query_nom_module.lastError().text();
    }
    QSqlQuery query(db_connection);
    query.prepare("SELECT * FROM students WHERE id =(SELECT id_etudiant from inscription WHERE id_module=:id_module)");
    query.bindValue(":id_module",id_module);

    if(query.exec()){
        qDebug() << "query executed";

        ui->etudiantTable->clear(); // Effacer les données précédentes

        // Définir les en-têtes (inclure la colonne "Supprimer")
        QStringList headers = {"ID", "Nom","Prenom", "CNE", "Adresse","Date-naissance","anner_bac", "diplome_obtenu","niveau_etudes", "Modifier", "Supprimer"};
        ui->etudiantTable->setColumnCount(headers.size());
        ui->etudiantTable->setHorizontalHeaderLabels(headers);

        ui->etudiantTable->setEditTriggers(QAbstractItemView::DoubleClicked | QAbstractItemView::SelectedClicked);


        // Charger les données ligne par ligne
        int row = 0;
        while (query.next()) {
            qDebug() << query.value("nom");
            // Récupérer l'ID avant toute autre opération
            int id = query.value("id").toInt();

            ui->etudiantTable->insertRow(row); // Ajouter une nouvelle ligne

            // Remplir chaque colonne
            ui->etudiantTable->setItem(row, 0, new QTableWidgetItem(QString::number(id)));
            ui->etudiantTable->setItem(row, 1, new QTableWidgetItem(query.value("nom").toString()));
            ui->etudiantTable->setItem(row, 2, new QTableWidgetItem(query.value("prenom").toString()));
            ui->etudiantTable->setItem(row, 3, new QTableWidgetItem(query.value("cne").toString()));
            ui->etudiantTable->setItem(row, 4, new QTableWidgetItem(query.value("adresse").toString()));
            ui->etudiantTable->setItem(row, 5, new QTableWidgetItem(query.value("date_naissance").toString()));
            ui->etudiantTable->setItem(row, 6, new QTableWidgetItem(query.value("annee_bac").toString()));
            ui->etudiantTable->setItem(row, 7, new QTableWidgetItem(query.value("diplome_obtenu").toString()));
            ui->etudiantTable->setItem(row, 8, new QTableWidgetItem(query.value("niveau_etudes").toString()));

            QPushButton *editButton = new QPushButton("Modifier");
            connect(editButton, &QPushButton::clicked, this, [=]() {
                // Récupérer les nouvelles valeurs de la ligne
                QString id = ui->etudiantTable->item(row, 0)->text();
                QString nom = ui->etudiantTable->item(row, 1)->text();
                QString prenom = ui->etudiantTable->item(row, 2)->text();
                QString cne = ui->etudiantTable->item(row, 3)->text();
                QString adresse = ui->etudiantTable->item(row, 4)->text();
                QString date = ui->etudiantTable->item(row, 5)->text();
                QString annee = ui->etudiantTable->item(row, 6)->text();
                QString diplome = ui->etudiantTable->item(row, 7)->text();
                QString niveau = ui->etudiantTable->item(row, 8)->text();

                // Préparer la requête de mise à jour
                QSqlQuery updateQuery(db_connection);
                updateQuery.prepare("UPDATE students SET nom=:nom,prenom=:prenom ,cne=:cne,adresse=:adresse,date_naissance=:date, annee_bac=:annee, diplome_obtenu=:diplome,niveau_etudes=:niveau WHERE id=:id");
                updateQuery.bindValue(":nom", nom);
                updateQuery.bindValue(":prenom", prenom);
                updateQuery.bindValue(":cne", cne);
                updateQuery.bindValue(":adresse", adresse);
                updateQuery.bindValue(":date", date);
                updateQuery.bindValue(":annee", annee);
                updateQuery.bindValue(":diplome", diplome);
                updateQuery.bindValue(":niveau", niveau);
                updateQuery.bindValue(":id", id);

                if (updateQuery.exec()) {
                    qDebug() << "letudiant modifié";
                }
                else {
                    qDebug() << "letudian n'est pas modifié";
                }
            });
            ui->etudiantTable->setCellWidget(row, 9, editButton);

            QPushButton *deleteButton = new QPushButton("Supprimer");
            connect(deleteButton, &QPushButton::clicked, this, [=]() {
                QSqlQuery delete_query(db_connection);
                delete_query.prepare("DELETE FROM students WHERE id=:id");
                delete_query.bindValue(":id", id);
                if(delete_query.exec()){
                    qDebug() << "letudiant selectionné est supprimé";
                }
                else{
                    qDebug() << "il ya un probleme lors de la suppression de l'etudiant";
                }
            });

            // Ajouter le bouton à la dernière colonne
            ui->etudiantTable->setCellWidget(row, 10, deleteButton);

            row++;
        }
    }
    else{
        qDebug() << "query not executed";
    }

}

affichage_etudiant_module::~affichage_etudiant_module()
{
    delete ui;
}
