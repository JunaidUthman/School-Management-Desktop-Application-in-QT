/********************************************************************************
** Form generated from reading UI file 'espace_admin.ui'
**
** Created by: Qt User Interface Compiler version 6.8.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_ESPACE_ADMIN_H
#define UI_ESPACE_ADMIN_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>

QT_BEGIN_NAMESPACE

class Ui_espace_admin
{
public:
    QLabel *label;
    QLabel *label_2;
    QLabel *label_3;
    QLineEdit *password_input;
    QPushButton *submit;
    QPushButton *exit;
    QPushButton *menue;
    QLineEdit *email_input;
    QLabel *label_4;
    QLabel *label_5;
    QLabel *label_7;
    QLabel *label_8;
    QLabel *label_6;

    void setupUi(QDialog *espace_admin)
    {
        if (espace_admin->objectName().isEmpty())
            espace_admin->setObjectName("espace_admin");
        espace_admin->resize(601, 377);
        espace_admin->setStyleSheet(QString::fromUtf8("background-color:white;"));
        label = new QLabel(espace_admin);
        label->setObjectName("label");
        label->setGeometry(QRect(250, 110, 121, 21));
        label->setStyleSheet(QString::fromUtf8("color:black;\n"
"font-family: Sylfaen;"));
        label_2 = new QLabel(espace_admin);
        label_2->setObjectName("label_2");
        label_2->setGeometry(QRect(210, 160, 41, 21));
        label_2->setStyleSheet(QString::fromUtf8("color: black;\n"
"font-family: Sylfaen;"));
        label_3 = new QLabel(espace_admin);
        label_3->setObjectName("label_3");
        label_3->setGeometry(QRect(210, 190, 51, 21));
        label_3->setStyleSheet(QString::fromUtf8("color: black ;\n"
"font-family: Sylfaen;"));
        password_input = new QLineEdit(espace_admin);
        password_input->setObjectName("password_input");
        password_input->setGeometry(QRect(270, 190, 113, 20));
        password_input->setStyleSheet(QString::fromUtf8("QLineEdit {\n"
"    background-color: #f9f9f9;       /* Couleur de fond */\n"
"    color: #333;                    /* Couleur du texte */\n"
"    border: 2px solid ;      /* Bordure verte */\n"
"    border-radius: 8px;             /* Coins arrondis */\n"
"    font-size: 10px;                /* Taille de la police */\n"
"    font-family: Arial, sans-serif; /* Police */\n"
"}\n"
"\n"
"QLineEdit:focus {\n"
"    border: 2px solid  #b8d7ff;      /* Bordure plus fonc\303\251e au focus */\n"
"    background-color: #e8f5e9;      /* Couleur de fond l\303\251g\303\250re au focus */\n"
"}"));
        password_input->setEchoMode(QLineEdit::EchoMode::Password);
        submit = new QPushButton(espace_admin);
        submit->setObjectName("submit");
        submit->setGeometry(QRect(270, 257, 81, 31));
        submit->setStyleSheet(QString::fromUtf8("\n"
"*{\n"
"    background-color: rgb(85,170,255) ; /* Couleur de fond */\n"
"color:black;\n"
"    \n"
"    border-radius: 10px 10px ;        /* Coins arrondis */\n"
"    color: white;               /* Couleur du texte */\n"
"    font-size: 10px;            /* Taille de la police */\n"
"    font-weight: bold;          /* Texte en gras */\n"
"font-family: Sylfaen;\n"
"    padding: 7px 2px;         /* Marges internes *\n"
"    text-align: center;         /* Alignement du texte */\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    background-color: #b8d7ff;  /* Couleur de fond au survol */\n"
"}"));
        exit = new QPushButton(espace_admin);
        exit->setObjectName("exit");
        exit->setGeometry(QRect(410, 260, 71, 31));
        exit->setStyleSheet(QString::fromUtf8("\n"
"\n"
"QPushButton {\n"
"    background-color: rgb(85,170,255) ; /* Couleur de fond */\n"
"    \n"
"    border-radius: 10px 10px ;        /* Coins arrondis */\n"
"    color: white;               /* Couleur du texte */\n"
"    font-size: 10px;            /* Taille de la police */\n"
"    font-weight: bold;          /* Texte en gras */\n"
"    padding: 7px 2px;         /* Marges internes */\n"
"font-family: Sylfaen;\n"
"    text-align: center;         /* Alignement du texte */\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    background-color:  #b8d7ff; /* Couleur de fond au survol */\n"
"}"));
        menue = new QPushButton(espace_admin);
        menue->setObjectName("menue");
        menue->setGeometry(QRect(130, 260, 71, 31));
        menue->setStyleSheet(QString::fromUtf8("\n"
"QPushButton {\n"
"    background-color: rgb(85,170,255) ; /* Couleur de fond */\n"
"    \n"
"    border-radius: 10px 10px ;        /* Coins arrondis */\n"
"    color: white;               /* Couleur du texte */\n"
"    font-size: 10px;            /* Taille de la police */\n"
"    font-weight: bold;          /* Texte en gras */\n"
"    padding: 7px 2px;         /* Marges internes */\n"
"font-family: Sylfaen;\n"
"    text-align: center;         /* Alignement du texte */\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    background-color: #b8d7ff;  /* Couleur de fond au survol */\n"
"}\n"
"\n"
"QPushButton:pressed {\n"
"    background-color: #388E3C;  /* Couleur de fond au clic */\n"
"    border: 2px solid #2E7D32;  /* Bordure plus sombre au clic */\n"
"}\n"
""));
        email_input = new QLineEdit(espace_admin);
        email_input->setObjectName("email_input");
        email_input->setGeometry(QRect(270, 160, 113, 20));
        email_input->setStyleSheet(QString::fromUtf8("QLineEdit {\n"
"    background-color: #f9f9f9;       /* Couleur de fond */\n"
"    color: #333;                    /* Couleur du texte */\n"
"    border: 2px solid ;      /* Bordure verte */\n"
"    border-radius: 8px;             /* Coins arrondis */\n"
"     font-size: 10px;                /* Taille de la police */\n"
"    font-family: Arial, sans-serif; /* Police */\n"
"}\n"
"\n"
"QLineEdit:focus {\n"
"   border: 2px solid  #b8d7ff;    /* Bordure plus fonc\303\251e au focus */\n"
"    background-color: #e8f5e9;      /* Couleur de fond l\303\251g\303\250re au focus */\n"
"}\n"
""));
        label_4 = new QLabel(espace_admin);
        label_4->setObjectName("label_4");
        label_4->setGeometry(QRect(280, 260, 21, 21));
        label_4->setStyleSheet(QString::fromUtf8("image: url(:/images/login.jpeg);"));
        label_5 = new QLabel(espace_admin);
        label_5->setObjectName("label_5");
        label_5->setGeometry(QRect(420, 270, 16, 16));
        label_5->setStyleSheet(QString::fromUtf8("border-image: url(:/images/logout.jpeg);"));
        label_7 = new QLabel(espace_admin);
        label_7->setObjectName("label_7");
        label_7->setGeometry(QRect(0, 10, 121, 31));
        label_7->setStyleSheet(QString::fromUtf8("image: url(:/images/fsttt.jpeg);"));
        label_8 = new QLabel(espace_admin);
        label_8->setObjectName("label_8");
        label_8->setGeometry(QRect(500, 10, 91, 41));
        label_8->setStyleSheet(QString::fromUtf8("image: url(:/images/uae2.jpeg);"));
        label_6 = new QLabel(espace_admin);
        label_6->setObjectName("label_6");
        label_6->setGeometry(QRect(140, 270, 16, 16));
        label_6->setStyleSheet(QString::fromUtf8("QLabel {\n"
"   	 /* Chemin de l'image */\n"
"	image: url(:/images/OIP.jfif);\n"
"    background-repeat: no-repeat;                         /* Pas de r\303\251p\303\251tition */\n"
"    background-position: center;                          /* Centrer l'image */\n"
"    background-size: 50px 50px;                           /* Taille r\303\251duite (50x50) */\n"
"                         /* Bordure optionnelle */\n"
"    border-radius: 100px;                                  /* Cr\303\251e un cercle (moiti\303\251 de la taille) */\n"
"    width: 50px;                                          /* Largeur du QLabel */\n"
"    height: 50px; \n"
"}\n"
""));

        retranslateUi(espace_admin);

        QMetaObject::connectSlotsByName(espace_admin);
    } // setupUi

    void retranslateUi(QDialog *espace_admin)
    {
        espace_admin->setWindowTitle(QCoreApplication::translate("espace_admin", "Dialog", nullptr));
        label->setText(QCoreApplication::translate("espace_admin", "Espace Administrateur", nullptr));
        label_2->setText(QCoreApplication::translate("espace_admin", "email", nullptr));
        label_3->setText(QCoreApplication::translate("espace_admin", "password", nullptr));
        submit->setText(QCoreApplication::translate("espace_admin", "        login", nullptr));
        exit->setText(QCoreApplication::translate("espace_admin", "    exit", nullptr));
        menue->setText(QCoreApplication::translate("espace_admin", "    menu", nullptr));
        label_4->setText(QString());
        label_5->setText(QString());
        label_7->setText(QCoreApplication::translate("espace_admin", "l", nullptr));
        label_8->setText(QString());
        label_6->setText(QString());
    } // retranslateUi

};

namespace Ui {
    class espace_admin: public Ui_espace_admin {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_ESPACE_ADMIN_H
