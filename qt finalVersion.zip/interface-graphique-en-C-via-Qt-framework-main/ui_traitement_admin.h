/********************************************************************************
** Form generated from reading UI file 'traitement_admin.ui'
**
** Created by: Qt User Interface Compiler version 6.8.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_TRAITEMENT_ADMIN_H
#define UI_TRAITEMENT_ADMIN_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QScrollArea>
#include <QtWidgets/QStackedWidget>
#include <QtWidgets/QTableWidget>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_traitement_admin
{
public:
    QWidget *sidebar;
    QPushButton *menue;
    QPushButton *etudiant;
    QPushButton *modules;
    QPushButton *pushButton_4;
    QPushButton *page_initiale;
    QPushButton *professeurs;
    QPushButton *pushButton;
    QPushButton *ajouter_prof;
    QPushButton *btn5;
    QLabel *label_22;
    QWidget *header;
    QLabel *label;
    QWidget *header_2;
    QLabel *label_24;
    QWidget *header_3;
    QLabel *label_25;
    QWidget *header_4;
    QLabel *label_26;
    QStackedWidget *mainpage;
    QWidget *menue_2;
    QLabel *label_2;
    QLabel *label_23;
    QWidget *ajoute_etudiant;
    QLabel *label_4;
    QLineEdit *lineEdit_11;
    QLineEdit *lineEdit_12;
    QLineEdit *lineEdit_13;
    QLineEdit *lineEdit_14;
    QLineEdit *lineEdit_15;
    QLineEdit *lineEdit_16;
    QLineEdit *lineEdit_17;
    QLineEdit *lineEdit_18;
    QLabel *label_6;
    QLabel *label_7;
    QLabel *label_8;
    QLabel *label_9;
    QLabel *label_10;
    QLabel *label_11;
    QLabel *label_12;
    QLabel *label_13;
    QPushButton *butnenr;
    QWidget *page;
    QLabel *label_5;
    QTableWidget *prf_table;
    QWidget *etudiant_2;
    QLabel *label_3;
    QPushButton *lsi3;
    QPushButton *lsi2;
    QPushButton *lsi1;
    QWidget *page_3;
    QLabel *label_20;
    QPushButton *lsi1_2;
    QPushButton *lsi2_2;
    QPushButton *lsi3_2;
    QLabel *label_image;
    QWidget *modules_2;
    QScrollArea *scrollArea;
    QWidget *scrollAreaWidgetContents;
    QWidget *gridWidget;
    QLabel *label_21;
    QWidget *page_2;
    QLabel *label_14;
    QPushButton *btnenregistrer;
    QLineEdit *lineEdit;
    QLineEdit *lineEdit_2;
    QLineEdit *lineEdit_3;
    QLineEdit *lineEdit_4;
    QLineEdit *lineEdit_5;
    QLabel *label_15;
    QLabel *label_16;
    QLabel *label_17;
    QLabel *label_18;
    QLabel *label_19;

    void setupUi(QDialog *traitement_admin)
    {
        if (traitement_admin->objectName().isEmpty())
            traitement_admin->setObjectName("traitement_admin");
        traitement_admin->resize(870, 498);
        sidebar = new QWidget(traitement_admin);
        sidebar->setObjectName("sidebar");
        sidebar->setGeometry(QRect(0, 0, 141, 501));
        sidebar->setStyleSheet(QString::fromUtf8("background-color: #2980B9;\n"
"border-color:#2980B9;\n"
""));
        menue = new QPushButton(sidebar);
        menue->setObjectName("menue");
        menue->setGeometry(QRect(0, 130, 141, 41));
        menue->setStyleSheet(QString::fromUtf8("/* Boutons de la sidebar */\n"
"\n"
"    background-color: #3498DB; /* Bleu l\303\251g\303\250rement plus clair */\n"
"    color: #FFFFFF; /* Texte blanc */\n"
"    font-weight: bold; /* Texte en gras */\n"
"    border: none; /* Pas de bordure */\n"
"    border-radius: 6px; /* Coins arrondis */\n"
"    padding: 8px 15px; /* Espacement int\303\251rieur */\n"
"    margin: 5px 10px; /* Espacement externe pour espacer les boutons */\n"
"    text-align: center; /* Alignement \303\240 gauche pour un style de menu */\n"
"font-size:11px;\n"
"\n"
"\n"
""));
        etudiant = new QPushButton(sidebar);
        etudiant->setObjectName("etudiant");
        etudiant->setGeometry(QRect(0, 210, 141, 41));
        etudiant->setStyleSheet(QString::fromUtf8("/* Boutons de la sidebar */\n"
"\n"
"    background-color: #3498DB; /* Bleu l\303\251g\303\250rement plus clair */\n"
"    color: #FFFFFF; /* Texte blanc */\n"
"    font-weight: bold; /* Texte en gras */\n"
"    border: none; /* Pas de bordure */\n"
"    border-radius: 6px; /* Coins arrondis */\n"
"    padding: 8px 15px; /* Espacement int\303\251rieur */\n"
"    margin: 5px 10px; /* Espacement externe pour espacer les boutons */\n"
"    text-align: center; /* Alignement \303\240 gauche pour un style de menu */\n"
"font-size:11px;\n"
""));
        modules = new QPushButton(sidebar);
        modules->setObjectName("modules");
        modules->setGeometry(QRect(0, 370, 141, 41));
        modules->setStyleSheet(QString::fromUtf8("/* Boutons de la sidebar */\n"
"\n"
"    background-color: #3498DB; /* Bleu l\303\251g\303\250rement plus clair */\n"
"    color: #FFFFFF; /* Texte blanc */\n"
"    font-weight: bold; /* Texte en gras */\n"
"    border: none; /* Pas de bordure */\n"
"    border-radius: 6px; /* Coins arrondis */\n"
"    padding: 8px 15px; /* Espacement int\303\251rieur */\n"
"    margin: 5px 10px; /* Espacement externe pour espacer les boutons */\n"
"    text-align: center; /* Alignement \303\240 gauche pour un style de menu */\n"
"font-size:11px;\n"
"\n"
""));
        pushButton_4 = new QPushButton(sidebar);
        pushButton_4->setObjectName("pushButton_4");
        pushButton_4->setGeometry(QRect(10, 460, 121, 41));
        pushButton_4->setStyleSheet(QString::fromUtf8("/* Boutons de la sidebar */\n"
"\n"
"    background-color: red; /* Bleu l\303\251g\303\250rement plus clair */\n"
"    color: #FFFFFF; /* Texte blanc */\n"
"    font-weight: bold; /* Texte en gras */\n"
"    border: none; /* Pas de bordure */\n"
"    border-radius: 6px; /* Coins arrondis */\n"
"    padding: 8px 15px; /* Espacement int\303\251rieur */\n"
"    margin: 5px 10px; /* Espacement externe pour espacer les boutons */\n"
"    text-align: center; /* Alignement \303\240 gauche pour un style de menu */\n"
"font-size:11px;"));
        page_initiale = new QPushButton(sidebar);
        page_initiale->setObjectName("page_initiale");
        page_initiale->setGeometry(QRect(10, 420, 121, 41));
        page_initiale->setStyleSheet(QString::fromUtf8("/* Boutons de la sidebar */\n"
"\n"
"    background-color: green; /* Bleu l\303\251g\303\250rement plus clair */\n"
"    color: #FFFFFF; /* Texte blanc */\n"
"    font-weight: bold; /* Texte en gras */\n"
"    border: none; /* Pas de bordure */\n"
"    border-radius: 6px; /* Coins arrondis */\n"
"    padding: 8px 15px; /* Espacement int\303\251rieur */\n"
"    margin: 5px 10px; /* Espacement externe pour espacer les boutons */\n"
"    text-align: center; /* Alignement \303\240 gauche pour un style de menu */\n"
"font-size:11px;\n"
""));
        professeurs = new QPushButton(sidebar);
        professeurs->setObjectName("professeurs");
        professeurs->setGeometry(QRect(0, 330, 141, 41));
        professeurs->setStyleSheet(QString::fromUtf8("/* Boutons de la sidebar */\n"
"\n"
"    background-color: #3498DB; /* Bleu l\303\251g\303\250rement plus clair */\n"
"    color: #FFFFFF; /* Texte blanc */\n"
"    font-weight: bold; /* Texte en gras */\n"
"    border: none; /* Pas de bordure */\n"
"    border-radius: 6px; /* Coins arrondis */\n"
"    padding: 8px 15px; /* Espacement int\303\251rieur */\n"
"    margin: 5px 10px; /* Espacement externe pour espacer les boutons */\n"
"    text-align: center; /* Alignement \303\240 gauche pour un style de menu */\n"
"font-size:11px;"));
        pushButton = new QPushButton(sidebar);
        pushButton->setObjectName("pushButton");
        pushButton->setGeometry(QRect(0, 170, 141, 41));
        pushButton->setStyleSheet(QString::fromUtf8("/* Boutons de la sidebar */\n"
"\n"
"    background-color: #3498DB; /* Bleu l\303\251g\303\250rement plus clair */\n"
"    color: #FFFFFF; /* Texte blanc */\n"
"    font-weight: bold; /* Texte en gras */\n"
"    border: none; /* Pas de bordure */\n"
"    border-radius: 6px; /* Coins arrondis */\n"
"    padding: 8px 15px; /* Espacement int\303\251rieur */\n"
"    margin: 5px 10px; /* Espacement externe pour espacer les boutons */\n"
"    text-align: center; /* Alignement \303\240 gauche pour un style de menu */\n"
"font-size:11px;\n"
""));
        ajouter_prof = new QPushButton(sidebar);
        ajouter_prof->setObjectName("ajouter_prof");
        ajouter_prof->setGeometry(QRect(0, 250, 141, 41));
        ajouter_prof->setStyleSheet(QString::fromUtf8("/* Boutons de la sidebar */\n"
"\n"
"    background-color: #3498DB; /* Bleu l\303\251g\303\250rement plus clair */\n"
"    color: #FFFFFF; /* Texte blanc */\n"
"    font-weight: bold; /* Texte en gras */\n"
"    border: none; /* Pas de bordure */\n"
"    border-radius: 6px; /* Coins arrondis */\n"
"    padding: 8px 15px; /* Espacement int\303\251rieur */\n"
"    margin: 5px 10px; /* Espacement externe pour espacer les boutons */\n"
"    text-align: center; /* Alignement \303\240 gauche pour un style de menu */\n"
"font-size:11px;\n"
"\n"
"\n"
""));
        btn5 = new QPushButton(sidebar);
        btn5->setObjectName("btn5");
        btn5->setGeometry(QRect(0, 290, 141, 41));
        btn5->setStyleSheet(QString::fromUtf8("/* Boutons de la sidebar */\n"
"\n"
"    background-color: #3498DB; /* Bleu l\303\251g\303\250rement plus clair */\n"
"    color: #FFFFFF; /* Texte blanc */\n"
"    font-weight: bold; /* Texte en gras */\n"
"    border: none; /* Pas de bordure */\n"
"    border-radius: 6px; /* Coins arrondis */\n"
"    padding: 8px 15px; /* Espacement int\303\251rieur */\n"
"    margin: 5px 10px; /* Espacement externe pour espacer les boutons */\n"
"    text-align: center; /* Alignement \303\240 gauche pour un style de menu */\n"
"font-size:11px;\n"
""));
        label_22 = new QLabel(sidebar);
        label_22->setObjectName("label_22");
        label_22->setGeometry(QRect(10, 0, 131, 131));
        label_22->setStyleSheet(QString::fromUtf8("font-size: 25px; /* Taille de police */\n"
"image: url(:/images/FST-Tanger-modified.png);\n"
"    font-weight: bold; /* Texte en gras */\n"
"    color: white; /* Couleur du texte */\n"
"    text-align: center; /* Centrer le texte */\n"
"    padding: 10px; /* Espacement int\303\251rieur */\n"
"border-color:#2980B9;\n"
""));
        header = new QWidget(traitement_admin);
        header->setObjectName("header");
        header->setGeometry(QRect(140, 0, 731, 101));
        header->setStyleSheet(QString::fromUtf8("background-color: #2980B9;\n"
"border-color:#2980B9;\n"
"\n"
"\n"
""));
        label = new QLabel(header);
        label->setObjectName("label");
        label->setGeometry(QRect(250, 20, 231, 51));
        label->setStyleSheet(QString::fromUtf8("font-size: 25px; /* Taille de police */\n"
"    font-weight: bold; /* Texte en gras */\n"
"    color: white; /* Couleur du texte */\n"
"    text-align: center; /* Centrer le texte */\n"
"    padding: 10px; /* Espacement int\303\251rieur */\n"
" \n"
"    border-radius: 10px; /* Coins arrondis */\n"
""));
        header_2 = new QWidget(header);
        header_2->setObjectName("header_2");
        header_2->setGeometry(QRect(60, 90, 731, 101));
        header_2->setStyleSheet(QString::fromUtf8("background-color: #2980B9;\n"
"border-color:#2980B9;\n"
"\n"
"\n"
""));
        label_24 = new QLabel(header_2);
        label_24->setObjectName("label_24");
        label_24->setGeometry(QRect(250, 20, 231, 51));
        label_24->setStyleSheet(QString::fromUtf8("font-size: 25px; /* Taille de police */\n"
"    font-weight: bold; /* Texte en gras */\n"
"    color: white; /* Couleur du texte */\n"
"    text-align: center; /* Centrer le texte */\n"
"    padding: 10px; /* Espacement int\303\251rieur */\n"
" \n"
"    border-radius: 10px; /* Coins arrondis */\n"
""));
        header_3 = new QWidget(header_2);
        header_3->setObjectName("header_3");
        header_3->setGeometry(QRect(10, 10, 731, 101));
        header_3->setStyleSheet(QString::fromUtf8("background-color: #2980B9;\n"
"border-color:#2980B9;\n"
"\n"
"\n"
""));
        label_25 = new QLabel(header_3);
        label_25->setObjectName("label_25");
        label_25->setGeometry(QRect(250, 20, 231, 51));
        label_25->setStyleSheet(QString::fromUtf8("font-size: 25px; /* Taille de police */\n"
"    font-weight: bold; /* Texte en gras */\n"
"    color: white; /* Couleur du texte */\n"
"    text-align: center; /* Centrer le texte */\n"
"    padding: 10px; /* Espacement int\303\251rieur */\n"
" \n"
"    border-radius: 10px; /* Coins arrondis */\n"
""));
        header_4 = new QWidget(header_3);
        header_4->setObjectName("header_4");
        header_4->setGeometry(QRect(10, 10, 731, 101));
        header_4->setStyleSheet(QString::fromUtf8("background-color: #2980B9;\n"
"border-color:#2980B9;\n"
"\n"
"\n"
""));
        label_26 = new QLabel(header_4);
        label_26->setObjectName("label_26");
        label_26->setGeometry(QRect(250, 20, 231, 51));
        label_26->setStyleSheet(QString::fromUtf8("font-size: 25px; /* Taille de police */\n"
"    font-weight: bold; /* Texte en gras */\n"
"    color: white; /* Couleur du texte */\n"
"    text-align: center; /* Centrer le texte */\n"
"    padding: 10px; /* Espacement int\303\251rieur */\n"
" \n"
"    border-radius: 10px; /* Coins arrondis */\n"
""));
        mainpage = new QStackedWidget(traitement_admin);
        mainpage->setObjectName("mainpage");
        mainpage->setGeometry(QRect(140, 100, 731, 401));
        mainpage->setStyleSheet(QString::fromUtf8("background-color: #F5F5F5;"));
        menue_2 = new QWidget();
        menue_2->setObjectName("menue_2");
        label_2 = new QLabel(menue_2);
        label_2->setObjectName("label_2");
        label_2->setGeometry(QRect(0, 0, 721, 391));
        label_2->setStyleSheet(QString::fromUtf8("font-size:30px;\n"
"color:#2980B9;"));
        label_23 = new QLabel(menue_2);
        label_23->setObjectName("label_23");
        label_23->setGeometry(QRect(180, 0, 351, 111));
        label_23->setStyleSheet(QString::fromUtf8("font-size: 30px; /* Taille de police */\n"
"    font-weight: bold; /* Texte en gras */\n"
"    color: #2980B9; /* Couleur du texte */\n"
"    text-align: center; /* Centrer le texte */\n"
"    padding: 10px; /* Espacement int\303\251rieur */\n"
" \n"
"    border-radius: 10px; /* Coins arrondis */\n"
"\n"
""));
        mainpage->addWidget(menue_2);
        ajoute_etudiant = new QWidget();
        ajoute_etudiant->setObjectName("ajoute_etudiant");
        label_4 = new QLabel(ajoute_etudiant);
        label_4->setObjectName("label_4");
        label_4->setGeometry(QRect(180, 0, 351, 81));
        label_4->setStyleSheet(QString::fromUtf8("font-size: 25px; /* Taille de police */\n"
"    font-weight: bold; /* Texte en gras */\n"
"    color: #2980B9; /* Couleur du texte */\n"
"    text-align: center; /* Centrer le texte */\n"
"    padding: 10px; /* Espacement int\303\251rieur */\n"
" \n"
"    border-radius: 10px; /* Coins arrondis */\n"
""));
        lineEdit_11 = new QLineEdit(ajoute_etudiant);
        lineEdit_11->setObjectName("lineEdit_11");
        lineEdit_11->setGeometry(QRect(170, 90, 113, 31));
        lineEdit_11->setStyleSheet(QString::fromUtf8("background-color:white;"));
        lineEdit_12 = new QLineEdit(ajoute_etudiant);
        lineEdit_12->setObjectName("lineEdit_12");
        lineEdit_12->setGeometry(QRect(510, 90, 113, 31));
        lineEdit_12->setStyleSheet(QString::fromUtf8("background-color:white;"));
        lineEdit_13 = new QLineEdit(ajoute_etudiant);
        lineEdit_13->setObjectName("lineEdit_13");
        lineEdit_13->setGeometry(QRect(170, 140, 113, 31));
        lineEdit_13->setStyleSheet(QString::fromUtf8("background-color:white;"));
        lineEdit_14 = new QLineEdit(ajoute_etudiant);
        lineEdit_14->setObjectName("lineEdit_14");
        lineEdit_14->setGeometry(QRect(510, 140, 113, 31));
        lineEdit_14->setStyleSheet(QString::fromUtf8("background-color:white;"));
        lineEdit_15 = new QLineEdit(ajoute_etudiant);
        lineEdit_15->setObjectName("lineEdit_15");
        lineEdit_15->setGeometry(QRect(170, 190, 113, 31));
        lineEdit_15->setStyleSheet(QString::fromUtf8("background-color:white;"));
        lineEdit_16 = new QLineEdit(ajoute_etudiant);
        lineEdit_16->setObjectName("lineEdit_16");
        lineEdit_16->setGeometry(QRect(510, 190, 113, 31));
        lineEdit_16->setStyleSheet(QString::fromUtf8("background-color:white;"));
        lineEdit_17 = new QLineEdit(ajoute_etudiant);
        lineEdit_17->setObjectName("lineEdit_17");
        lineEdit_17->setGeometry(QRect(510, 240, 113, 31));
        lineEdit_17->setStyleSheet(QString::fromUtf8("background-color:white;"));
        lineEdit_18 = new QLineEdit(ajoute_etudiant);
        lineEdit_18->setObjectName("lineEdit_18");
        lineEdit_18->setGeometry(QRect(170, 240, 113, 31));
        lineEdit_18->setStyleSheet(QString::fromUtf8("background-color:white;"));
        label_6 = new QLabel(ajoute_etudiant);
        label_6->setObjectName("label_6");
        label_6->setGeometry(QRect(60, 80, 61, 41));
        label_6->setStyleSheet(QString::fromUtf8("font-size: 15px; /* Taille de police */\n"
"    font-weight: bold; /* Texte en gras */\n"
"    color: black; /* Couleur du texte */\n"
"    text-align: center; /* Centrer le texte */\n"
"    padding: 10px; /* Espacement int\303\251rieur */\n"
"\n"
""));
        label_7 = new QLabel(ajoute_etudiant);
        label_7->setObjectName("label_7");
        label_7->setGeometry(QRect(370, 90, 101, 41));
        label_7->setStyleSheet(QString::fromUtf8("font-size: 15px; /* Taille de police */\n"
"    font-weight: bold; /* Texte en gras */\n"
"    color: black; /* Couleur du texte */\n"
"    text-align: center; /* Centrer le texte */\n"
"    padding: 10px; /* Espacement int\303\251rieur */\n"
"\n"
""));
        label_8 = new QLabel(ajoute_etudiant);
        label_8->setObjectName("label_8");
        label_8->setGeometry(QRect(370, 130, 101, 51));
        label_8->setStyleSheet(QString::fromUtf8("font-size: 15px; /* Taille de police */\n"
"    font-weight: bold; /* Texte en gras */\n"
"    color: black; /* Couleur du texte */\n"
"    text-align: center; /* Centrer le texte */\n"
"    padding: 10px; /* Espacement int\303\251rieur */\n"
"\n"
""));
        label_9 = new QLabel(ajoute_etudiant);
        label_9->setObjectName("label_9");
        label_9->setGeometry(QRect(60, 130, 61, 41));
        label_9->setStyleSheet(QString::fromUtf8("font-size: 15px; /* Taille de police */\n"
"    font-weight: bold; /* Texte en gras */\n"
"    color: black; /* Couleur du texte */\n"
"    text-align: center; /* Centrer le texte */\n"
"    padding: 10px; /* Espacement int\303\251rieur */\n"
"\n"
""));
        label_10 = new QLabel(ajoute_etudiant);
        label_10->setObjectName("label_10");
        label_10->setGeometry(QRect(370, 180, 131, 51));
        label_10->setStyleSheet(QString::fromUtf8("font-size: 15px; /* Taille de police */\n"
"    font-weight: bold; /* Texte en gras */\n"
"    color: black; /* Couleur du texte */\n"
"    text-align: center; /* Centrer le texte */\n"
"    padding: 10px; /* Espacement int\303\251rieur */\n"
"\n"
""));
        label_11 = new QLabel(ajoute_etudiant);
        label_11->setObjectName("label_11");
        label_11->setGeometry(QRect(350, 230, 151, 41));
        label_11->setStyleSheet(QString::fromUtf8("font-size: 15px; /* Taille de police */\n"
"    font-weight: bold; /* Texte en gras */\n"
"    color: black; /* Couleur du texte */\n"
"    text-align: center; /* Centrer le texte */\n"
"    padding: 10px; /* Espacement int\303\251rieur */\n"
"\n"
""));
        label_12 = new QLabel(ajoute_etudiant);
        label_12->setObjectName("label_12");
        label_12->setGeometry(QRect(10, 180, 141, 51));
        label_12->setStyleSheet(QString::fromUtf8("font-size: 15px; /* Taille de police */\n"
"    font-weight: bold; /* Texte en gras */\n"
"    color: black; /* Couleur du texte */\n"
"    text-align: center; /* Centrer le texte */\n"
"    padding: 10px; /* Espacement int\303\251rieur */\n"
"\n"
""));
        label_13 = new QLabel(ajoute_etudiant);
        label_13->setObjectName("label_13");
        label_13->setGeometry(QRect(10, 230, 131, 51));
        label_13->setStyleSheet(QString::fromUtf8("font-size: 15px; /* Taille de police */\n"
"    font-weight: bold; /* Texte en gras */\n"
"    color: black; /* Couleur du texte */\n"
"    text-align: center; /* Centrer le texte */\n"
"    padding: 10px; /* Espacement int\303\251rieur */\n"
"\n"
""));
        butnenr = new QPushButton(ajoute_etudiant);
        butnenr->setObjectName("butnenr");
        butnenr->setGeometry(QRect(310, 310, 121, 41));
        butnenr->setStyleSheet(QString::fromUtf8("/* Boutons de la sidebar */\n"
"\n"
"    background-color: #3498DB; /* Bleu l\303\251g\303\250rement plus clair */\n"
"    color: #FFFFFF; /* Texte blanc */\n"
"    font-weight: bold; /* Texte en gras */\n"
"    border: none; /* Pas de bordure */\n"
"    border-radius: 6px; /* Coins arrondis */\n"
"    padding: 8px 15px; /* Espacement int\303\251rieur */\n"
"    margin: 5px 10px; /* Espacement externe pour espacer les boutons */\n"
"    text-align: center; /* Alignement \303\240 gauche pour un style de menu */\n"
"font-size:11px;"));
        mainpage->addWidget(ajoute_etudiant);
        page = new QWidget();
        page->setObjectName("page");
        label_5 = new QLabel(page);
        label_5->setObjectName("label_5");
        label_5->setGeometry(QRect(270, 10, 211, 41));
        label_5->setStyleSheet(QString::fromUtf8("font-size:20px;\n"
"color:black;"));
        prf_table = new QTableWidget(page);
        prf_table->setObjectName("prf_table");
        prf_table->setGeometry(QRect(10, 61, 711, 321));
        prf_table->setStyleSheet(QString::fromUtf8("background-color:#F2F6FA;\n"
"color:#2C3E50;\n"
"\n"
"QHeaderView::section {\n"
"    background-color: #2980B9; /* Bleu vif */\n"
"    color: #FFFFFF; /* Texte blanc */\n"
"    font-weight: bold; /* Texte en gras */\n"
"    font-size: 14px; /* Taille de la police */\n"
"    padding: 8px; /* Espacement int\303\251rieur */\n"
"    border: 1px solid #21618C; /* Bordure autour de chaque section */\n"
"    text-align: center; /* Alignement centr\303\251 */\n"
"}\n"
"\n"
"/* Bordure autour de l'en-t\303\252te */\n"
"QHeaderView {\n"
"    border: 1px solid #BDC3C7; /* Bordure ext\303\251rieure */\n"
"}"));
        mainpage->addWidget(page);
        etudiant_2 = new QWidget();
        etudiant_2->setObjectName("etudiant_2");
        label_3 = new QLabel(etudiant_2);
        label_3->setObjectName("label_3");
        label_3->setGeometry(QRect(240, 20, 261, 51));
        label_3->setStyleSheet(QString::fromUtf8("font-size: 25px; /* Taille de police */\n"
"    font-weight: bold; /* Texte en gras */\n"
"    color: #2980B9; /* Couleur du texte */\n"
"    text-align: center; /* Centrer le texte */\n"
"    padding: 10px; /* Espacement int\303\251rieur */\n"
" \n"
"    border-radius: 10px; /* Coins arrondis */\n"
""));
        lsi3 = new QPushButton(etudiant_2);
        lsi3->setObjectName("lsi3");
        lsi3->setGeometry(QRect(500, 140, 221, 171));
        lsi3->setStyleSheet(QString::fromUtf8("/* Boutons de la sidebar */\n"
"\n"
"    background-color: #3498DB; /* Bleu l\303\251g\303\250rement plus clair */\n"
"    color: #FFFFFF; /* Texte blanc */\n"
"    font-weight: bold; /* Texte en gras */\n"
"    border: none; /* Pas de bordure */\n"
"    border-radius: 6px; /* Coins arrondis */\n"
"    padding: 8px 15px; /* Espacement int\303\251rieur */\n"
"    margin: 5px 10px; /* Espacement externe pour espacer les boutons */\n"
"    text-align: center; /* Alignement \303\240 gauche pour un style de menu */\n"
"font-size:11px;"));
        lsi2 = new QPushButton(etudiant_2);
        lsi2->setObjectName("lsi2");
        lsi2->setGeometry(QRect(250, 140, 221, 171));
        lsi2->setStyleSheet(QString::fromUtf8("/* Boutons de la sidebar */\n"
"\n"
"    background-color: #3498DB; /* Bleu l\303\251g\303\250rement plus clair */\n"
"    color: #FFFFFF; /* Texte blanc */\n"
"    font-weight: bold; /* Texte en gras */\n"
"    border: none; /* Pas de bordure */\n"
"    border-radius: 6px; /* Coins arrondis */\n"
"    padding: 8px 15px; /* Espacement int\303\251rieur */\n"
"    margin: 5px 10px; /* Espacement externe pour espacer les boutons */\n"
"    text-align: center; /* Alignement \303\240 gauche pour un style de menu */\n"
"font-size:11px;"));
        lsi1 = new QPushButton(etudiant_2);
        lsi1->setObjectName("lsi1");
        lsi1->setGeometry(QRect(10, 140, 211, 171));
        lsi1->setStyleSheet(QString::fromUtf8("/* Boutons de la sidebar */\n"
"\n"
"    background-color: #3498DB; /* Bleu l\303\251g\303\250rement plus clair */\n"
"    color: #FFFFFF; /* Texte blanc */\n"
"    font-weight: bold; /* Texte en gras */\n"
"    border: none; /* Pas de bordure */\n"
"    border-radius: 6px; /* Coins arrondis */\n"
"    padding: 8px 15px; /* Espacement int\303\251rieur */\n"
"    margin: 5px 10px; /* Espacement externe pour espacer les boutons */\n"
"    text-align: center; /* Alignement \303\240 gauche pour un style de menu */\n"
"font-size:11px;"));
        mainpage->addWidget(etudiant_2);
        page_3 = new QWidget();
        page_3->setObjectName("page_3");
        label_20 = new QLabel(page_3);
        label_20->setObjectName("label_20");
        label_20->setGeometry(QRect(250, 0, 271, 51));
        label_20->setStyleSheet(QString::fromUtf8("font-size: 25px; /* Taille de police */\n"
"    font-weight: bold; /* Texte en gras */\n"
"    color: #2980B9; /* Couleur du texte */\n"
"    text-align: center; /* Centrer le texte */\n"
"    padding: 10px; /* Espacement int\303\251rieur */\n"
" \n"
"    border-radius: 10px; /* Coins arrondis */\n"
""));
        lsi1_2 = new QPushButton(page_3);
        lsi1_2->setObjectName("lsi1_2");
        lsi1_2->setGeometry(QRect(20, 70, 141, 41));
        lsi1_2->setStyleSheet(QString::fromUtf8("/* Boutons de la sidebar */\n"
"\n"
"    background-color: #3498DB; /* Bleu l\303\251g\303\250rement plus clair */\n"
"    color: #FFFFFF; /* Texte blanc */\n"
"    font-weight: bold; /* Texte en gras */\n"
"    border: none; /* Pas de bordure */\n"
"    border-radius: 6px; /* Coins arrondis */\n"
"    padding: 8px 15px; /* Espacement int\303\251rieur */\n"
"    margin: 5px 10px; /* Espacement externe pour espacer les boutons */\n"
"    text-align: center; /* Alignement \303\240 gauche pour un style de menu */\n"
"font-size:11px;\n"
"\n"
"\n"
""));
        lsi2_2 = new QPushButton(page_3);
        lsi2_2->setObjectName("lsi2_2");
        lsi2_2->setGeometry(QRect(290, 70, 151, 41));
        lsi2_2->setStyleSheet(QString::fromUtf8("/* Boutons de la sidebar */\n"
"\n"
"    background-color: #3498DB; /* Bleu l\303\251g\303\250rement plus clair */\n"
"    color: #FFFFFF; /* Texte blanc */\n"
"    font-weight: bold; /* Texte en gras */\n"
"    border: none; /* Pas de bordure */\n"
"    border-radius: 6px; /* Coins arrondis */\n"
"    padding: 8px 15px; /* Espacement int\303\251rieur */\n"
"    margin: 5px 10px; /* Espacement externe pour espacer les boutons */\n"
"    text-align: center; /* Alignement \303\240 gauche pour un style de menu */\n"
"font-size:11px;\n"
"\n"
"\n"
""));
        lsi3_2 = new QPushButton(page_3);
        lsi3_2->setObjectName("lsi3_2");
        lsi3_2->setGeometry(QRect(590, 70, 131, 41));
        lsi3_2->setStyleSheet(QString::fromUtf8("/* Boutons de la sidebar */\n"
"\n"
"    background-color: #3498DB; /* Bleu l\303\251g\303\250rement plus clair */\n"
"    color: #FFFFFF; /* Texte blanc */\n"
"    font-weight: bold; /* Texte en gras */\n"
"    border: none; /* Pas de bordure */\n"
"    border-radius: 6px; /* Coins arrondis */\n"
"    padding: 8px 15px; /* Espacement int\303\251rieur */\n"
"    margin: 5px 10px; /* Espacement externe pour espacer les boutons */\n"
"    text-align: center; /* Alignement \303\240 gauche pour un style de menu */\n"
"font-size:11px;\n"
"\n"
"\n"
""));
        label_image = new QLabel(page_3);
        label_image->setObjectName("label_image");
        label_image->setGeometry(QRect(10, 110, 711, 271));
        mainpage->addWidget(page_3);
        modules_2 = new QWidget();
        modules_2->setObjectName("modules_2");
        scrollArea = new QScrollArea(modules_2);
        scrollArea->setObjectName("scrollArea");
        scrollArea->setGeometry(QRect(10, 60, 711, 331));
        scrollArea->setStyleSheet(QString::fromUtf8("background-color:gray;"));
        scrollArea->setWidgetResizable(true);
        scrollAreaWidgetContents = new QWidget();
        scrollAreaWidgetContents->setObjectName("scrollAreaWidgetContents");
        scrollAreaWidgetContents->setGeometry(QRect(0, 0, 709, 329));
        gridWidget = new QWidget(scrollAreaWidgetContents);
        gridWidget->setObjectName("gridWidget");
        gridWidget->setGeometry(QRect(0, 0, 711, 371));
        gridWidget->setStyleSheet(QString::fromUtf8("background-color:#F2F6FA;"));
        scrollArea->setWidget(scrollAreaWidgetContents);
        label_21 = new QLabel(modules_2);
        label_21->setObjectName("label_21");
        label_21->setGeometry(QRect(240, 0, 241, 51));
        label_21->setStyleSheet(QString::fromUtf8("font-size: 25px; /* Taille de police */\n"
"    font-weight: bold; /* Texte en gras */\n"
"    color: #2980B9; /* Couleur du texte */\n"
"    text-align: center; /* Centrer le texte */\n"
"    padding: 10px; /* Espacement int\303\251rieur */\n"
" \n"
"    border-radius: 10px; /* Coins arrondis */\n"
""));
        mainpage->addWidget(modules_2);
        page_2 = new QWidget();
        page_2->setObjectName("page_2");
        label_14 = new QLabel(page_2);
        label_14->setObjectName("label_14");
        label_14->setGeometry(QRect(220, 0, 291, 61));
        label_14->setStyleSheet(QString::fromUtf8("font-size: 25px; /* Taille de police */\n"
"    font-weight: bold; /* Texte en gras */\n"
"    color: #2980B9; /* Couleur du texte */\n"
"    text-align: center; /* Centrer le texte */\n"
"    padding: 10px; /* Espacement int\303\251rieur */\n"
" \n"
"    border-radius: 10px; /* Coins arrondis */\n"
""));
        btnenregistrer = new QPushButton(page_2);
        btnenregistrer->setObjectName("btnenregistrer");
        btnenregistrer->setGeometry(QRect(270, 300, 171, 61));
        btnenregistrer->setStyleSheet(QString::fromUtf8("/* Boutons de la sidebar */\n"
"\n"
"    background-color: #3498DB; /* Bleu l\303\251g\303\250rement plus clair */\n"
"    color: #FFFFFF; /* Texte blanc */\n"
"    font-weight: bold; /* Texte en gras */\n"
"    border: none; /* Pas de bordure */\n"
"    border-radius: 6px; /* Coins arrondis */\n"
"    padding: 8px 15px; /* Espacement int\303\251rieur */\n"
"    margin: 5px 10px; /* Espacement externe pour espacer les boutons */\n"
"    text-align: center; /* Alignement \303\240 gauche pour un style de menu */\n"
"font-size:20px;\n"
""));
        lineEdit = new QLineEdit(page_2);
        lineEdit->setObjectName("lineEdit");
        lineEdit->setGeometry(QRect(160, 100, 151, 31));
        lineEdit->setStyleSheet(QString::fromUtf8("background-color:white;"));
        lineEdit_2 = new QLineEdit(page_2);
        lineEdit_2->setObjectName("lineEdit_2");
        lineEdit_2->setGeometry(QRect(550, 100, 151, 31));
        lineEdit_2->setStyleSheet(QString::fromUtf8("background-color:white;"));
        lineEdit_3 = new QLineEdit(page_2);
        lineEdit_3->setObjectName("lineEdit_3");
        lineEdit_3->setGeometry(QRect(160, 160, 151, 31));
        lineEdit_3->setStyleSheet(QString::fromUtf8("background-color:white;"));
        lineEdit_4 = new QLineEdit(page_2);
        lineEdit_4->setObjectName("lineEdit_4");
        lineEdit_4->setGeometry(QRect(550, 160, 151, 31));
        lineEdit_4->setStyleSheet(QString::fromUtf8("background-color:white;"));
        lineEdit_5 = new QLineEdit(page_2);
        lineEdit_5->setObjectName("lineEdit_5");
        lineEdit_5->setGeometry(QRect(370, 240, 151, 31));
        lineEdit_5->setStyleSheet(QString::fromUtf8("background-color:white;"));
        label_15 = new QLabel(page_2);
        label_15->setObjectName("label_15");
        label_15->setGeometry(QRect(40, 90, 91, 41));
        label_15->setStyleSheet(QString::fromUtf8("font-size: 15px; /* Taille de police */\n"
"    font-weight: bold; /* Texte en gras */\n"
"    color: black; /* Couleur du texte */\n"
"    text-align: center; /* Centrer le texte */\n"
"    padding: 10px; /* Espacement int\303\251rieur */\n"
"\n"
""));
        label_16 = new QLabel(page_2);
        label_16->setObjectName("label_16");
        label_16->setGeometry(QRect(420, 90, 91, 51));
        label_16->setStyleSheet(QString::fromUtf8("font-size: 15px; /* Taille de police */\n"
"    font-weight: bold; /* Texte en gras */\n"
"    color: black; /* Couleur du texte */\n"
"    text-align: center; /* Centrer le texte */\n"
"    padding: 10px; /* Espacement int\303\251rieur */\n"
"\n"
""));
        label_17 = new QLabel(page_2);
        label_17->setObjectName("label_17");
        label_17->setGeometry(QRect(40, 150, 91, 41));
        label_17->setStyleSheet(QString::fromUtf8("font-size: 15px; /* Taille de police */\n"
"    font-weight: bold; /* Texte en gras */\n"
"    color: black; /* Couleur du texte */\n"
"    text-align: center; /* Centrer le texte */\n"
"    padding: 10px; /* Espacement int\303\251rieur */\n"
"\n"
""));
        label_18 = new QLabel(page_2);
        label_18->setObjectName("label_18");
        label_18->setGeometry(QRect(420, 150, 91, 41));
        label_18->setStyleSheet(QString::fromUtf8("font-size: 15px; /* Taille de police */\n"
"    font-weight: bold; /* Texte en gras */\n"
"    color: black; /* Couleur du texte */\n"
"    text-align: center; /* Centrer le texte */\n"
"    padding: 10px; /* Espacement int\303\251rieur */\n"
"\n"
""));
        label_19 = new QLabel(page_2);
        label_19->setObjectName("label_19");
        label_19->setGeometry(QRect(220, 230, 91, 41));
        label_19->setStyleSheet(QString::fromUtf8("font-size: 15px; /* Taille de police */\n"
"    font-weight: bold; /* Texte en gras */\n"
"    color: black; /* Couleur du texte */\n"
"    text-align: center; /* Centrer le texte */\n"
"    padding: 10px; /* Espacement int\303\251rieur */\n"
"\n"
""));
        mainpage->addWidget(page_2);

        retranslateUi(traitement_admin);

        mainpage->setCurrentIndex(4);


        QMetaObject::connectSlotsByName(traitement_admin);
    } // setupUi

    void retranslateUi(QDialog *traitement_admin)
    {
        traitement_admin->setWindowTitle(QCoreApplication::translate("traitement_admin", "Dialog", nullptr));
        menue->setText(QCoreApplication::translate("traitement_admin", " menu", nullptr));
        etudiant->setText(QCoreApplication::translate("traitement_admin", "etudiants", nullptr));
        modules->setText(QCoreApplication::translate("traitement_admin", "modules", nullptr));
        pushButton_4->setText(QCoreApplication::translate("traitement_admin", "exit", nullptr));
        page_initiale->setText(QCoreApplication::translate("traitement_admin", "page initiale", nullptr));
        professeurs->setText(QCoreApplication::translate("traitement_admin", "ajouter etudiant", nullptr));
        pushButton->setText(QCoreApplication::translate("traitement_admin", "professeurs", nullptr));
        ajouter_prof->setText(QCoreApplication::translate("traitement_admin", "ajouter prof", nullptr));
        btn5->setText(QCoreApplication::translate("traitement_admin", "emplois du temps", nullptr));
        label_22->setText(QString());
        label->setText(QCoreApplication::translate("traitement_admin", "   FST TANGER", nullptr));
        label_24->setText(QCoreApplication::translate("traitement_admin", "   FST TANGER", nullptr));
        label_25->setText(QCoreApplication::translate("traitement_admin", "   FST TANGER", nullptr));
        label_26->setText(QCoreApplication::translate("traitement_admin", "   FST TANGER", nullptr));
        label_2->setText(QString());
        label_23->setText(QCoreApplication::translate("traitement_admin", "Espace Administrateur", nullptr));
        label_4->setText(QCoreApplication::translate("traitement_admin", "     Ajouter un Etudiant", nullptr));
        label_6->setText(QCoreApplication::translate("traitement_admin", "nom", nullptr));
        label_7->setText(QCoreApplication::translate("traitement_admin", "Pr\303\251nom", nullptr));
        label_8->setText(QCoreApplication::translate("traitement_admin", "Adresse", nullptr));
        label_9->setText(QCoreApplication::translate("traitement_admin", "CNE", nullptr));
        label_10->setText(QCoreApplication::translate("traitement_admin", "Ann\303\251e bac", nullptr));
        label_11->setText(QCoreApplication::translate("traitement_admin", "Diplome Obtenue", nullptr));
        label_12->setText(QCoreApplication::translate("traitement_admin", "Date_Naissance", nullptr));
        label_13->setText(QCoreApplication::translate("traitement_admin", "Niveau d'etude", nullptr));
        butnenr->setText(QCoreApplication::translate("traitement_admin", "enregistrer", nullptr));
        label_5->setText(QCoreApplication::translate("traitement_admin", "Liste Des Professeurs", nullptr));
        label_3->setText(QCoreApplication::translate("traitement_admin", "Listes D'Etudiants", nullptr));
        lsi3->setText(QCoreApplication::translate("traitement_admin", "LSI 3", nullptr));
        lsi2->setText(QCoreApplication::translate("traitement_admin", "LSI 2", nullptr));
        lsi1->setText(QCoreApplication::translate("traitement_admin", "LSI 1", nullptr));
        label_20->setText(QCoreApplication::translate("traitement_admin", "Emploi du Temps", nullptr));
        lsi1_2->setText(QCoreApplication::translate("traitement_admin", "LSI 1", nullptr));
        lsi2_2->setText(QCoreApplication::translate("traitement_admin", "LSI 2", nullptr));
        lsi3_2->setText(QCoreApplication::translate("traitement_admin", "LSI 3", nullptr));
        label_image->setText(QString());
        label_21->setText(QCoreApplication::translate("traitement_admin", "Liste Des Modules", nullptr));
        label_14->setText(QCoreApplication::translate("traitement_admin", "Ajouter un Professeur", nullptr));
        btnenregistrer->setText(QCoreApplication::translate("traitement_admin", "Enregistrer", nullptr));
        label_15->setText(QCoreApplication::translate("traitement_admin", "Nom", nullptr));
        label_16->setText(QCoreApplication::translate("traitement_admin", "Pr\303\251nom", nullptr));
        label_17->setText(QCoreApplication::translate("traitement_admin", "Email", nullptr));
        label_18->setText(QCoreApplication::translate("traitement_admin", "Password", nullptr));
        label_19->setText(QCoreApplication::translate("traitement_admin", "Module", nullptr));
    } // retranslateUi

};

namespace Ui {
    class traitement_admin: public Ui_traitement_admin {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_TRAITEMENT_ADMIN_H
