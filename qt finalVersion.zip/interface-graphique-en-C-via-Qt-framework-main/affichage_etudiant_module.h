#ifndef AFFICHAGE_ETUDIANT_MODULE_H
#define AFFICHAGE_ETUDIANT_MODULE_H

#include <QDialog>
#include <QString>
#include<QSqlDatabase>

namespace Ui {
class affichage_etudiant_module;
}

class affichage_etudiant_module : public QDialog
{
    Q_OBJECT

public:
    explicit affichage_etudiant_module(int id_module,QWidget *parent = nullptr);
    ~affichage_etudiant_module();

private:
    Ui::affichage_etudiant_module *ui;
    int id_module;
    QSqlDatabase db_connection;
};

#endif // AFFICHAGE_ETUDIANT_MODULE_H
